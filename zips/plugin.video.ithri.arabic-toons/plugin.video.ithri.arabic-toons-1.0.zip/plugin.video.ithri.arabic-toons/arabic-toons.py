# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Rifalbum.com
# Version 0.1

#-----------------------Codigo Util-------------------------------------
import sys
import urllib,re,urlparse, json, array
import xbmc,xbmcgui,xbmcplugin
import requests
from resources.lib import tools
from resources.lib import common as c

_host = c.host
_headers = c.headers('Chrome')
c.addon_data()
c.addon_temp()

PluginHandle = int(sys.argv[1])

def Menu():
    addDir('Latest Animes','Animes','Latest','','')
    addDir('Latest Movies','Movies','Latest','','')
    #addDir('Latest Books','Books','Latest','','')
    addDir('Cartoon & Anime','Animes','Category','','')
    addDir('Movies','Movies','Category','','')
    addDir('Live TV',_host+'animetv.php','Live_TV','','')
    #addDir('Watch Later','myanime','my_anime','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Latest():
    link = args['url'][0]
    r = requests.get(_host, headers=_headers)
    paterns = '<div.*?"shado".*?<a title="(.*?)" href="(.*?)".*?img src="(.*?)".*?/>'
    matches = re.findall(paterns, r.content, re.DOTALL)

    if link == "Animes":
        for x in range(0,5):
            title = matches[x][0]
            url = _host + matches[x][1]
            img = matches[x][2]
            addDir(title,url,'Episodes',img,'')

    elif link == "Movies":
        for x in range(5,10):
            title = matches[x][0]
            url = _host + matches[x][1]
            img = matches[x][2]
            addLink(title,url,'Streams',img,'')

    elif link == "Books":
        for x in range(10,15):
            title = matches[x][0]
            url = _host + matches[x][1]
            img = matches[x][2]
            addLink(title,url,'',img,'')
    #xbmc.executebuiltin('Container.SetViewMode(51)')
    xbmcplugin.endOfDirectory(PluginHandle)

def Category():
    link = args['url'][0]
    if link == "Animes":
        addDir('All','cartoon.php','Entities','','')
        addDir('Abc','cartoon.php','Abc','','')
    elif link == "Movies":
        addDir('All','movies.php','Movies','','')
        addDir('Abc','movies.php','Abc','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Abc():
    link = _host + args['url'][0]
    r = requests.get(link, headers=_headers)
    paterns = "<li><a.*?ground.*?href='(.*?)'.*?<span>(.*?)</span></a"
    abc = re.findall(paterns, r.content, re.DOTALL)
    for url, alpha in abc:
            addDir(alpha,url,'Entities','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Entities():
    link = _host + args['url'][0]
    r = requests.get(link, headers=_headers)
    paterns = '<div.*?"shado".*?<a title="(.*?)" href="(.*?)".*?img src="(.*?)".*?/>'
    animes = re.findall(paterns, r.content, re.DOTALL)
    for title, url, img in animes:
        url = _host + url
        addDir(title,url,'Episodes',img,'')

    pagin = re.findall('table><div.*?pagin.*?"current".*?</spa.*?<a href="(.*?)">(.*?)</a>', r.content, re.DOTALL)
    if pagin:
            for url, pag in pagin:
                addDir('Next Page => '+pag,url,'Entities','','')

    xbmcplugin.endOfDirectory(PluginHandle)

def Episodes():
    link = args['url'][0]
    r = requests.get(link, headers=_headers)
    paterns = '<div.*?"shado".*?<a title="(.*?)" href="(.*?)".*?img src="(.*?)".*?/>'
    episodes = re.findall(paterns, r.content, re.DOTALL)    
    for title, url, img in episodes:
        addLink(title,url,'Streams',img,'')
    xbmcplugin.endOfDirectory(PluginHandle)
    
def Live_TV():
    link = args['url'][0]
    r = requests.get(link, headers=_headers)
    paterns = '<li.*?<a.*?"Live.*?href="(.*?toons.com/(.*?)-en.*?)".*?<img.*?src="(.*?)".*?>(.*?)</a></li>'
    channels = re.findall(paterns, r.content, re.DOTALL)
    for url,title_lt, img, title_ar in channels:
        img = _host+img
        addLink(title_lt,url,'Streams',img,'')
    xbmcplugin.endOfDirectory(PluginHandle)

def Streams():
    link = args['url'][0]
    r = requests.get(link, headers=_headers)
    title = re.findall('<title>(.*?)</title>', r.content, re.DOTALL)[0]

    if "unescape" in r.content:
        data = urllib.unquote(r.content)
        paterns = 'provider.*?url.*?"(.*?)"'
        file = re.findall(paterns, data, re.DOTALL)[0]
    else:       

        Stream_url =[]
        Stream_name = []
        paterns = '<iframe src="(.*?)".*?>'
        url = re.findall(paterns, r.content, re.DOTALL)[0]

        r = requests.get(url, headers=_headers)

        headers_data = r.headers
        cookies_data = r.headers.get('set-cookie')
        cookies = "|Cookie=%s" % urllib.quote(str(cookies_data))

        itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
                         '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
                         '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
                         '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
                         '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
                         '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
                         '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
                         '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
                         '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
                         '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}

        


        data = re.findall('\|(https.*?yes),', r.content)            
        for url in data:
            
            url = url.replace('\u003d','=').replace('\u0026','&').replace('%2C',',')+cookies
            for match in re.finditer('itag=(?P<itag>[^&]+)', url):
                itag = match.group('itag')
                quality = itag_map.get(itag, 'Unknown Quality [%s]' % itag)
                name ='[Server : Google] %sP' % quality
            Stream_url.append(url)
            Stream_name.append(name)

        if (Stream_url):
            dialog = xbmcgui.Dialog()
            ret = dialog.select(title +' - Select Server',Stream_name) 

            if ret >= 0: 
                file = Stream_url[ret]        
            else: return False
    if file:
        Play_Streams(file,title)
    xbmcplugin.endOfDirectory(PluginHandle)

def Play_Streams(file,name):
    if file:
        listitem = xbmcgui.ListItem(path = file)
        listitem.setInfo( type="video", infoLabels={ "title": name } )            
        xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    else:
        xbmcgui.Dialog().ok(c.Addon_name,'Notification(Info: Kein Stream gefunden,)')

def addLink(name,url,mode,iconimage,plot,cm=False):
    plot = "ffgf rd fg fgff f gf gs f f f rd gfdgf gfg df gf gfgf ggfdg fgfg"
    labels = {
        'title': name,
        'sorttitle': name,
        'year': '',
        'studio': 'Arabic Toons',
        'duration': '',
        'playcount': '',
        'plot': plot
    }
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+str(name)
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    item.setArt({ 'fanart': iconimage, 'banner' : iconimage })
    #item.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
    #item.setInfo( type="Video", infoLabels={ "Title" : name, "Plot" : plot, "duration" : "5:30" } )
    item.setInfo( type="Video", infoLabels=labels )

    item.setProperty('IsPlayable', 'true')
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)

def addDir(name,url,mode,iconimage,plot,cm=False):
    labels = {
        'title': name,
        'year': '',
        'studio': 'Arabic Toons',
        'plot': plot
    }
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
    item=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setArt({ 'fanart': iconimage, 'banner' : iconimage })
    item.setInfo( type="Video", infoLabels=labels )
    if cm:
        item.addContextMenuItems( cm )
    #elif cm and mode =='Foeeeelgen':
        #cm = []
        #u4=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&name="+urllib.quote_plus(name)+"&mode="+urllib.quote_plus('add_to_my_anime')+"&iconimage="+urllib.quote_plus(iconimage)
        #cm.append( ('Add To My Anime', "XBMC.RunPlugin(%s)" % u4) )
        #item.addContextMenuItems( cm )

    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)

def add_to_my_anime():
    try:
        type = args['type'][0]
        title = args['name'][0]
        url = args['url'][0]
        cover = args['cover'][0]
        tools.set_my_anime(type,title,url,cover)
    except: pass

def remove_my_anime():
    try:
        url = args['url'][0]
        tools.remove_my_anime(url)
    except: pass

def remove_history():
    key = args['name'][0]
    url = args['url'][0]
    try: 
        tools.remove_history(key,url)
    except: pass

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    Menu()
else:
    exec '%s()' % mode[0]