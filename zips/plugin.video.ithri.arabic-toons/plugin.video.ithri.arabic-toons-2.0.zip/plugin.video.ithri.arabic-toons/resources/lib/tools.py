# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Rifalbum.com
# Version 0.1

import os,re,xbmc
import requests
import json
from resources.lib import common
headers = common.headers('Chrome')

def get_thumbs (img):
    return os.path.join(common.Addon_thumbs,img)

def trans(string):
    return common.Translations(string).encode("utf-8")

def SourceCode(content):
    File = open(common.HTMLData,'a')
    File.write(str(content)+'\n')
    File.close()
    
def save_json(file,data):
    json_file = open(file,"w")
    json.dump(data,json_file,indent=4)
    json_file.close()

def json_load(file):
    if os.path.exists(file):
        with open(file) as jf:
            json_data = json.load(jf)
        if json_data:
            return json_data

def set_abc(data):
    json_file = open(common.JSONData,"w")
    json.dump(data,json_file,indent=4)
    json_file.close()

def get_thumb(title):
    try:
        json_data = json_load(common.thumbnail)
        items = json_data[0]
        for i in json_data:
            i_name = i['items'][0]['name']
            i_cover = i['items'][0]['cover']
            if i_cover and i_name == title:
                return i_cover
    except: pass

def get_history():
    return json_load(common.history)

def set_history(key,url):
    entries = json_load(common.history)
    new_entry = {'key': key, 'url': url}
    try:
        for entry in entries:
            if entry['key'] == key and entry['url'] == url:
                return
        entries.append(new_entry)
        save_json(common.history,entries)
    except:
        save_json(common.history,[new_entry])

def set_my_anime(type,title,url,cover):
    entries = json_load(common.my_anime)
    new_entry = {'type': type, 'url': url,'title': title,'cover':cover}
    try:
        for entry in entries:
            if entry['url'] == url and entry['title'] == title:
                xbmc.executebuiltin('Notification(Anime ['+title+']: Bereits Hinzugef\xc3\xbcgt,)')
                return
        entries.append(new_entry)
        save_json(common.my_anime,entries)
        xbmc.executebuiltin('Notification(Anime ['+title+']: Hinzugef\xc3\xbcgt,)')
    except:
        save_json(common.my_anime,[new_entry])
        xbmc.executebuiltin('Notification(Anime ['+title+']: Hinzugef\xc3\xbcgt,)')

def get_my_anime():
        return json_load(common.my_anime)

def remove_my_anime(url):
    try:
        with open(common.my_anime) as f:
            json_data = json.load(f)
        for i in xrange(len(json_data)):
            if json_data[i]["url"] == url:
                title = json_data[i]["title"]
                json_data.pop(i)
                break
        save_json(common.my_anime,json_data)
        xbmc.executebuiltin('Notification(Anime: '+title.encode('utf-8')+' Entfernt,)')
    except: xbmc.executebuiltin('Notification(Anime: No Ha Sido Eliminado,)')

def remove_history(key,url):
    with open(common.history) as f:
        json_data = json.load(f)
    for i in xrange(len(json_data)):
        if json_data[i]["url"] == url and json_data[i]["key"] == key:
            name = json_data[i]["key"]
            json_data.pop(i)
            break
    save_json(common.history,json_data)
    xbmc.executebuiltin('Notification(Anime: '+name+' Entfernt,)')