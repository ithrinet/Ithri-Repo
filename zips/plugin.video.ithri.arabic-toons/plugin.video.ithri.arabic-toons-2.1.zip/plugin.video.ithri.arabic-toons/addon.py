# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Rifalbum.com
# Version 0.1

#-----------------------Codigo Util-------------------------------------
import sys
import urllib,re,urlparse
import xbmcgui,xbmcplugin
import requests
from resources.lib import tools as t
from resources.lib import common as c

Headers = c.headers('Chrome')

c.addon_data()
c.addon_temp()

#reload(sys)
#sys.setdefaultencoding('utf-8')

PluginHandle = int(sys.argv[1])
dialog = xbmcgui.Dialog()

session = requests.Session()
session.get(c.BaseUrl,headers=Headers)
cookies = requests.utils.dict_from_cookiejar(session.cookies)

def Menu():
    addDir('Latest Animes','0','Latest','','')
    addDir('Latest Movies','1','Latest','','')
    #addDir('Latest Books','Books','Latest','','')
    addDir('Cartoon & Anime','Animes','Category','','')
    addDir('Movies','Movies','Category','','')
    addDir('Live TV','/animetv.php','LiveTV','','')
    #addDir('Watch Later','myanime','my_anime','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Latest():
    key = args['url'][0]
    items = t.Request(c.BaseUrl).find_all(class_="rounded filled shadow ")[int(key)].find_all(class_="shado")

    for item in items:        
        title = item.find(class_="details").a.string
        url = '%s/%s' % (c.BaseUrl,item.a['href'])
        plot = t.Request(url).find("meta",property="og:description")['content']
        img = item.img['src']
        if key == '0':
            setcontent = 'tvshows'
            addDir(title,url,'Episodes',img,plot)
        else:
            setcontent = 'movies'
            addLink(title,url,'Streams',img,plot)

    xbmcplugin.setContent(PluginHandle, setcontent)
    #xbmc.executebuiltin('Container.SetViewMode(51)')
    xbmcplugin.endOfDirectory(PluginHandle)

def LiveTV():
    host = '%s/%s' % (c.BaseUrl,args['url'][0])
    html = t.Request(host)
    items = html.find_all(class_="menu")
    for item in items:
        url = item['href']
        title = re.findall('m/(.*?)-en',url)[0]
        img = "%s/%s" % (c.BaseUrl,item.img['src'])
        addLink(title,url,'Streams',img,'')
    xbmcplugin.endOfDirectory(PluginHandle)

def Category():
    host =  args['url'][0]
    if host == "Animes":
        addDir('All','cartoon.php','Items','','')
        addDir('Abc','cartoon.php','Abc','','')
    elif host == "Movies":
        addDir('All','movies.php','Items','','')
        addDir('Abc','movies.php','Abc','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Abc():
    host = '%s/%s' % (c.BaseUrl,args['url'][0])
    r = requests.get(host, headers=Headers,cookies=cookies)
    paterns = "<li><a.*?ground.*?href='(.*?)'.*?<span>(.*?)</span></a"
    Items = re.findall(paterns, r.content, re.DOTALL)
    Items.reverse()
    for url, alpha in Items:
        addDir(alpha,url,'Items','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Items():
    try:
        host = args['url'][0]

        if host == 'cartoon.php' or host == 'movies.php':
            cat = ''

        elif 'cat=' not in host:
            if args['cat'][0] != '':
                cat = '&cat=%s' % args['cat'][0]
            else:
                cat = '&cat='
        else:
            cat = ''

        host = '%s/%s%s' % (c.BaseUrl,host,cat)
        html = t.Request(host)
        items = html.find_all(class_="shado")
        pages = re.findall('table><div.*?pagin.*?"current".*?</spa.*?<a href="(.*?)">(.*?)</a>', str(html), re.DOTALL)

        for item in items:
            title = item.find(class_="details").a.string
            url = '%s/%s' % (c.BaseUrl,item.a['href'])
            img = item.img['src']
            desc = t.Request(url).find("meta",property="og:description")
            plot = desc['content'] if desc else ''

            if 'cartoon.php' in host:
                addDir(title,url,'Episodes',img,plot)
            else:            
                addLink(title,url,'Streams',img,plot)

        if pages:
                for url, pag in pages:
                    url = url.replace('&amp;','&')
                    addDir('Next Page : '+pag,url,'Items','','')
        xbmcplugin.setContent(PluginHandle, 'tvshows')
        #xbmc.executebuiltin('Container.SetViewMode(%s)'% VIEWS)
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Anime gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Episodes():
    try:
        host = args['url'][0]
        html = t.Request(host)
        items = html.find_all(class_="shado")
        plot = html.find("meta",property="og:description")['content']
        for item in items:
            #title = item.find(class_="details").a.string
            eps = re.sub(r'[^\d]+','',item.img['title']).strip()
            url = item.a['href']
            img = item.img['src']
            name = '%03d' % int(eps)
            addLink(name,url,'Streams',img,plot)
        xbmcplugin.setContent(PluginHandle, 'episodes')
        #xbmc.executebuiltin('Container.SetViewMode(%s)'% VIEWS)
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Anime gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Streams():
    #try:
        import urlresolver

        title = args['name'][0]
        img = args['iconimage'][0]
        host = args['url'][0]

        html = t.Request(host)
        plot = html.find("meta",property="og:description")['content'] if html.find("meta",property="og:description") else ''

        #t.SourceCode(html)

        if "unescape" in str(html):
            data = urllib.unquote(str(html))
            player = re.findall('"player", "(.*?)",', data, re.DOTALL)[0]
            file = re.findall('provider.*?url.*?"(.*?)"', data, re.DOTALL)[0]
            key = re.findall('key: "(.*?)"', data, re.DOTALL)[0]

            file = '%s swfUrl=%s pageUrl=%s live=1'% (file,player,host)

        elif '<iframe' in str(html):
            file = urlresolver.resolve(html.find("iframe")['src'])

        elif 'en-direct-live' in host:
            player = re.findall('"player", "(.*?)",',str(html), re.DOTALL)[0]
            url = re.findall('ipadUrl: "(.*?),',str(html))[0]
            file = '%s swfUrl=%s pageUrl=%s live=true'% (url,'http://www.arabic-toons.com/flowplayer.swf',host)
            t.SourceCode(file)
        else:
            file = ""

        if file:
            listitem = xbmcgui.ListItem(path = file)
            listitem.setInfo( type="video", infoLabels={ "title": title,'plot':plot } )
            listitem.setArt({ 'fanart': img,'poster': img,'banner' : img })          
            xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    #except:
        #dialog.notification(c.Addon_name, 'Info: Kein Stream Link', xbmcgui.NOTIFICATION_INFO, 5000)

#---------------------------------Codigo Antiguo----------------------

def addLink(name,url,mode,iconimage,plot,cm=False):
    labels = {
        'title': name,
        'sorttitle': name,
        'studio': 'Arabic Toons',
        'duration': '',
        'playcount': '',
        'plot': plot
    }

    #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+str(name)
    u = '%s?mode=%s&url=%s&name=%s&iconimage=%s' % (sys.argv[0],mode,url,name,iconimage)
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    item.setArt({ 'fanart': iconimage,'poster': iconimage, 'banner' : iconimage, 'thumb':iconimage })
    item.setInfo( type="Video", infoLabels=labels )
    item.setProperty('IsPlayable', 'true')
    if cm:
        item.addContextMenuItems( cm )

    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)

def addDir(name,url,mode,iconimage,plot,cm=False):
    labels = {
        'title': name,
        'sorttitle': name,
        'studio': 'Arabic-Toons',
        'duration': '',
        'playcount': '',
        'plot': plot
    }
    u=sys.argv[0]+"?url="+url+"&mode="+mode+"&name="+name+"&iconimage="+iconimage
    #u = '%s?mode=%s&url=%s&name=%s&iconimage=%s' % (sys.argv[0],mode,url,name,iconimage)
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    item.setArt({ 'fanart': iconimage,'poster': iconimage, 'banner' : iconimage, 'thumb':iconimage })
    item.setInfo( type="Video", infoLabels=labels )
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)

def add_to_my_anime():
    try:
        type = args['type'][0]
        title = args['name'][0]
        url = args['url'][0]
        cover = args['cover'][0]
        t.set_my_anime(type,title,url,cover)
    except: pass

def remove_my_anime():
    try:
        url = args['url'][0]
        t.remove_my_anime(url)
    except: pass

def remove_history():
    key = args['name'][0]
    url = args['url'][0]
    try: 
        t.remove_history(key,url)
    except: pass

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    Menu()
else:
    exec '%s()' % mode[0]