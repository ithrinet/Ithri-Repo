# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Rifalbum.com
# Version 0.1

#-----------------------Codigo Util-------------------------------------
import sys
import urllib,re,urlparse, json, array
import xbmc,xbmcgui,xbmcplugin
import requests
from resources.lib import tools, resolver
from resources.lib import common as c

_host = c.host
_headers = c.headers('Chrome')
c.addon_data()
c.addon_temp()

PluginHandle = int(sys.argv[1])

def Menu():
    addDir('Latest Episodes','Episodes','Latest','','','','','','','','')
    addDir('Latest Animes','Animes','Latest','','','','','','','','')
    addDir('Latest Movies','Movies','Latest','','','','','','','','')
    addDir('Animes','Animes','Category','','','','','','','','')
    addDir('Movies','Movies','Category','','','','','','','','')
    addDir('Search','/search?utf8=✓&%5Bsearch%5D=','Search','','','','','','','','')
    
    #addDir('Watch Later','myanime','my_anime','','','','','','','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Latest():
    link = args['url'][0]
    r = requests.get(_host, headers=_headers)
    paterns = '<li>.*?<a href="(.*?)".*?box.*?<img src="(.*?)".*?title\'>(.*?)</p>.*?</a></li>'

    if link == 'Episodes':
        data = re.findall('on-going-carousel\'>(.*?)</ul>', r.content, re.DOTALL)[0]
        matches = re.findall(paterns, data, re.DOTALL)

        for url, cover, title in matches:
            url = _host + url
            cover = _host + cover            
            ep = re.findall('episodes.*?(\d+)',url)[0]

            meta_data = tools.get_metadata(url,'') 
            fanart = _host + meta_data[0]
            year = meta_data[1]
            director = meta_data[2]
            plot = meta_data[3]
            studio = meta_data[5]            
            status = meta_data[6]
            genre = meta_data[7]            
            rating = meta_data[8]
            #tools.SourceCode('Studio: '+studio+' | Director: '+director+' | Year: '+year+' | Rating: '+rating+' | Status: '+status)

            addLink(title+' - '+ep,url,'Streams',cover,plot,fanart,year,genre,studio,director,status)

    elif link == 'Movies':
        data = re.findall('last-movies-carousel\'>(.*?)</ul>', r.content, re.DOTALL)[0]
        matches = re.findall(paterns, data, re.DOTALL)
        for url, cover, title in matches:
            url = _host + url
            cover = _host + cover

            meta_data = tools.get_metadata(url,'') 
            fanart = _host + meta_data[0]
            year = meta_data[1]
            director = meta_data[2]
            plot = meta_data[3]
            studio = meta_data[5]
            genre = meta_data[7]

            addLink(title,url,'Streams',cover,plot,fanart,year,genre,studio,director,'')

    elif link == 'Animes':
        data = re.findall('last-animes-carousel\'>(.*?)</ul>', r.content, re.DOTALL)[0]
        matches = re.findall(paterns, data, re.DOTALL)

        for url, cover, title in matches:
            url = _host+url
            cover = _host + cover

            meta_data = tools.get_metadata(url,'') 
            fanart = _host + meta_data[0]
            year = meta_data[1]
            director = meta_data[2]
            plot = meta_data[3]
            studio = meta_data[5]
            status = meta_data[6]
            genre = meta_data[7]
            rating = meta_data[8]
            addDir(title,url,'Episodes',cover,plot,fanart,year,genre,studio,director,status)

    xbmcplugin.setContent(PluginHandle, 'movies')
    #xbmc.executebuiltin('Container.SetViewMode(51)')
    xbmcplugin.endOfDirectory(PluginHandle)
    
def Search():
    link = _host+args['url'][0]
    kb = xbmc.Keyboard('', 'Suche Okanime.com', False)
    kb.doModal()
    search = kb.getText()
    url = link + search
    r = requests.get(url, headers=_headers)
    paterns = '<div.*?ol-md-15.*?l-xs.*?<a href="(.*?)".*?<img class="img.*?src="(.*?)".*?<span>(.*?)</span>.*?title\'>(.*?)</span>'
    animes = re.findall(paterns, r.content, re.DOTALL)

    for url, cover, poit,title,in animes:
        url = _host + url
        cover = _host + cover

        meta_data = tools.get_metadata(url,'')
        
        fanart = _host + meta_data[0]
        year = meta_data[1]
        director = meta_data[2]
        plot = meta_data[3]
        studio = meta_data[5]
        status = meta_data[6]
        genre = meta_data[7]
        rating = meta_data[8]

        if '/animes/' in url:
            addDir(title,url,'Episodes',cover,plot,fanart,year,genre,studio,director,status)
        elif '/movies/' in url:
            url = url.replace('/review','')
            addLink(title,url,'Streams',cover,plot,fanart,year,genre,studio,director,'')

    xbmcplugin.setContent(PluginHandle, 'movies')
    xbmcplugin.endOfDirectory(PluginHandle)

def Category():
    link = args['url'][0]
    if link == "Animes":
        addDir('All',_host +'/animes','Entities','','','','','','','','')
        addDir('A-Z',_host +'/animes','Abc','','','','','','','','')
    elif link == "Movies":
        addDir('All',_host +'/movies','Entities','','','','','','','','')
        addDir('A-Z',_host +'/movies','Abc','','','','','','','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Abc():
    link = args['url'][0]
    r = requests.get(link, headers=_headers)    
    data = re.findall("<div class='row alphabet'>(.*?)</div>", r.content, re.DOTALL)[0]
    paterns = '<a href="(.*?)">(.*?)</a>'
    abc = re.findall(paterns, data)
    for url, alpha in abc:
        if '&amp;' in url:
            url = _host + url.replace('&amp;','&')

        if 'الكل' in alpha:
            alpha = alpha.replace('الكل','#')
        addDir(alpha,url,'Entities','','','','','','','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Entities():
    link = args['url'][0]
    r = requests.get(link, headers=_headers)
    paterns = '<div.*?ol-md-15.*?l-xs.*?<a href="(.*?)".*?<img class="img.*?src="(.*?)".*?<span>(.*?)</span>.*?title\'>(.*?)</span>'
    animes = re.findall(paterns, r.content, re.DOTALL)
    #tools.SourceCode(link)

    for url, cover, poit,title,in animes:
        url = _host + url
        
        meta_data = tools.get_metadata(url,'') 
        fanart = _host + meta_data[0]
        year = meta_data[1]
        director = meta_data[2]
        plot = meta_data[3]
        studio = meta_data[5]
        status = meta_data[6]
        genre = meta_data[7]
        rating = meta_data[8]

        cover = _host + cover
        if '/animes/' in url:
            addDir(title,url,'Episodes',cover,plot,fanart,year,genre,studio,director,status)
        elif '/movies/' in url:
            addLink(title,url,'Streams',cover,plot,fanart,year,genre,studio,director,status)

    pagin = re.findall('next">.*?<a rel="next" href="(.*?)".*?next">Next</', r.content, re.DOTALL)
    if pagin:
            for url in pagin:
                url = _host + url.replace('&amp;','&')
                addDir('Next Page',url,'Entities','','','','','','','','')

    xbmcplugin.setContent(PluginHandle, 'movies')
    xbmcplugin.endOfDirectory(PluginHandle)

def Episodes():
    link = args['url'][0]
    #tools.SourceCode(link)

    if 'episodes' not in link:
        content= requests.get(link, headers=_headers).content
        url = _host + re.findall('ter container\'>.*?btn-watch" href="(.*?)">', content, re.DOTALL)[0]
    else:
        url = link
        content =''
    
    r = requests.get(url, headers=_headers)
    episodes = re.findall('episode" href="(.*?)"><li>(.*?)</li>', r.content, re.DOTALL)

    meta_data = tools.get_metadata(url,'') 
    fanart = _host + meta_data[0]
    year = meta_data[1]
    director = meta_data[2]
    plot = meta_data[3]
    cover = _host + meta_data[4]
    studio = meta_data[5]
    status = meta_data[6]
    genre = meta_data[7]
    rating = meta_data[8]

    for url, episode in episodes:
        addLink(episode,_host+url,'Streams',cover,plot,fanart,year,genre,studio,director,status)

    xbmcplugin.setContent(PluginHandle, 'episodes')
    xbmcplugin.endOfDirectory(PluginHandle)

def Streams():    
    link = args['url'][0]
    play_url = []
    play_name = []
    servers = []

    if '/movies' in link:
        link = link.replace('/review','')

    r = requests.get(link, headers=_headers)

    if '/animes/' in link:
        title = re.findall("<h4 class='latin'>\n(.*?)\n</h4>", r.content, re.DOTALL)[0]
    else:
        title = re.findall("<h3 class='title'>\n(.*?)\n</h3>", r.content, re.DOTALL)[0]


    url = re.findall('#remote_file.*?href="(.*?)">', r.content, re.DOTALL)[0]
    data_json = requests.get(_host+url, headers=_headers).json()

    servers.append(data_json['url'])
    
    streams = resolver.get_streams(servers)

    for name, url in streams:     
        play_url.append(url)
        play_name.append(name)

    try:
        if (play_url):
            dialog = xbmcgui.Dialog()
            ret = dialog.select(title + ' - Select Server ',play_name) 

            if ret >= 0: 
                file = play_url[ret]        
            else: return False
        if file:
            Play_Streams(file,title)
        xbmcplugin.endOfDirectory(PluginHandle)
    except: xbmcgui.Dialog().ok(c.Addon_name,'Notification(Info: Kein Stream gefunden,)')

def Play_Streams(file,name):
    #tools.SourceCode(file)
    if file:
        listitem = xbmcgui.ListItem(path = file)
        listitem.setInfo( type="video", infoLabels={ "title": name } )            
        xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    else:
        xbmcgui.Dialog().ok(c.Addon_name,'Notification(Info: Kein Stream gefunden,)')

def addLink(name,url,mode,iconimage,plot,fanart,year,genre,studio,director,status,cm=False):
    
    labels = {'title': name,'sorttitle': name,'genre': genre,'year': year,'studio': studio,'director':director,'status':status,
            'duration': '','plot': plot,'episode': '255555','rating': '9.9'
        }
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+str(name)
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    item.setArt({ 'fanart': fanart, 'banner' : fanart })
    item.setInfo( type="Video", infoLabels=labels )
    item.setProperty('IsPlayable', 'true')

    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)

def addDir(name,url,mode,iconimage,plot,fanart,year,genre,studio,director,status,cm=False):
    if mode == 'Episodes':
        labels = {'title': name,'sorttitle': name,'genre': genre,'year': year,'studio': studio,'director':director,'status':status,
            'duration': '','plot': plot,'episode': '255555','rating': '9.9'
        }
    else:
        labels = {'title': name,'plot': plot
        }
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    item.setArt({ 'fanart': fanart, 'banner' : fanart })
    item.setInfo( type="Video", infoLabels=labels )
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    Menu()
else:
    exec '%s()' % mode[0]