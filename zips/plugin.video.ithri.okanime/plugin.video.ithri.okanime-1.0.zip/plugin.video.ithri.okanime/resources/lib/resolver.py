# -*- coding: utf-8 -*-

import re, xbmc, urllib, xbmcgui
import requests
from resources.lib import tools,common
import json
from resources.lib import common as c

_host = c.host
headers = common.headers('Chrome')
sources = []

def get_streams(host_list):
    streams = None
    for host in host_list:
        if 'google.' in host:
            streams = google(host)
        elif 'mp4upload' in host:
            streams = mp4upload(host)
        elif 'dailymotion' in host:
            streams = dailymotion(host)
        elif 'cloudtime' in host or 'nowvideo' in host: 
            streams = player_api(host)
        elif 'izanagi' in host:
            streams = izanagi(host)
        elif 'yotta' in host:
            streams = yotta(host)
        elif 'yourupload' in host:
            streams = yourupload(host)
        elif 'videoweed' in host:
            streams = videoweed(host)
        elif 'novamov' in host:
            streams = novamov(host)
        #else:
           # tools.server_detect(host)
    return streams

def google(url):
    r = requests.get(url, headers=headers)

    headers_data = r.headers
    cookies_data = r.headers.get('set-cookie')
    cookies = "|Cookie=%s" % urllib.quote(str(cookies_data))

    data = re.findall('\|(https.*?),', r.content)
    for url in data:
        
        url = url.replace('\u003d','=').replace('\u0026','&').replace('%2C',',')+cookies
        for match in re.finditer('itag=(?P<itag>[^&]+)', url):
            itag = match.group('itag')
            quality = itag_map.get(itag, 'Unknown Quality [%s]' % itag)
            name ='[Server : Google] %sP' % quality
        sources.append((name,url))
    return sources
    #except Exception, e:
        #print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def novamov(host):
    try:
        file = urlresolver.resolve(host)
        if file :
            name = '[Server : Novamov ]'
            sources.append((name,file))
            return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def videoweed(host):
    try:
        file = urlresolver.resolve(host)
        if file :
            name = '[Server : Videoweed ]'
            sources.append((name,file))
            return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def yourupload(host):
    try:
        file = urlresolver.resolve(host)
        if file :
            name = '[Server : Yourupload ]'
            sources.append((name,file))
            return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def yotta(url):
    try:
        name = 'Server : Yotta '
        content = requests.get(url, headers=headers).content
        host = re.findall("\$.get\('(.*?)',", content)[0]
        data_json = requests.get(host, headers=headers).json()
        data_json = data_json['sources']
        for items in data_json:
            file = items['file']
            label = items['label']
            if file:
                name = '[Server : Yotta '+label+' ]'
                sources.append((name,file))
        return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def izanagi(url):
    try:
        url = url.replace('embed_izanagi.php?key','servers/izanagi.php?id')
        data_json = requests.get(url, headers=headers).json()
        file = data_json['file']
        if file:
            name = '[Server : Izanagi ]'
            sources.append((name,file))
            return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def player_api(url):
    #url = 'http://embed.nowvideo.sx/embed/?v=8c8cb72a27138''
    if 'cloudtime' in url: 
        host = 'www.cloudtime.to' 
        name = '[Server : Cloudtime ]'
    if 'nowvideo' in url:        
        host = 'www.nowvideo.sx'
        url = url.replace('embed.php?v=','embed/?v=')
        name = '[Server : Nowvideo ]'
    if 'novamov' in url:
        
        url = url.replace('embed.php?v=','embed/?v=')
        host = 'www.novamov.com' 
        name = '[Server : Novamov ]'
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.3)', 'Host': host}
        api_url = 'http://%s/api/player.api.php?key=%s&file=%s'
        content = requests.get(url).text
        _file = re.findall('file="(.+?)"', content)[0]
        try: 
            _key = re.findall('filekey="(.+?)"', content)[0]
        except: 
            match = re.findall('filekey=(.+?);', content)[0]
            _key = re.findall(match+'="(.+?)"', content)[0]

        content = requests.get(api_url % (host,_key,_file), headers=headers).text
        url = re.findall('url=(.+?)&', content)[0]
        if url :
            sources.append((name,url))
            return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def mp4upload(url):
    try:
        r = requests.get(url, headers=headers)
        url = re.findall('(http://.*?mp4upload.com.*?/d/.*?.mp4)', r.text)[0]
        name = '[Server : Mp4upload ]'
        if r.status_code == 200 and url:
            sources.append((name,url))
            return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def dailymotion(url):
    content = requests.get(url, headers=Headers).content.replace("\\/","/")
    data = re.search('({"context".+?)\);\n', content, re.DOTALL)
    name = '[Server : Dailymotion ]'
    try:
        if data:
            data = json.loads(data.group(1))

        if 'metadata' in data: data = data['metadata']
        else: return
        if 'qualities' in data:
            data = data['qualities']

        try: sources.append((data['1080'][0]['url'],'[Server : Dailymotion 1080 ]'))
        except: pass
        try: sources.append((data['720'][0]['url'],'[Server : Dailymotion 720 ]'))
        except: pass
        try: sources.append((data['480'][0]['url'],'[Server : Dailymotion 480 ]'))
        except: pass
        try: sources.append((data['380'][0]['url'],'[Server : Dailymotion 380 ]'))
        except: pass
        try: sources.append((data['auro'][0]['url'],'[Server : Dailymotion ][auto]'))
        except: pass
        return sources
    except: pass

def shared(url):
    try:
         
        s = requests.Session()
        content = s.get(url, timeout=timeout).text
        data = {}
        r = re.findall(r'type="hidden" name="(.+?)"\s* value="?(.+?)"', content)
        for name, value in r:
            data[name] = value
        content = s.post(url, data=data, timeout=timeout).text
        url = re.findall('data-url="(.*?)"', content)[0]
        if url:
            name ='Server : 4shared'
            sources.append((name,url))
            return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver shared error', e

def cartoonarabi(host):
    try:
        url = host.replace('/watch.php?','/videos.php?')
        name ='[Server : Cartoonarabi]'
        if url:
            sources.append((name,url))
            return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
                 '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
                 '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
                 '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
                 '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
                 '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
                 '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
                 '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
                 '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
                 '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}