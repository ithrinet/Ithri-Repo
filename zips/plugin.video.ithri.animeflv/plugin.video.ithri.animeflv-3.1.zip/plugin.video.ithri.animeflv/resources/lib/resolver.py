# -*- coding: utf-8 -*-

import re, xbmc, urllib, xbmcgui
import requests, urlresolver
from resources.lib import tools
from resources.lib import common as c
import json


_host = c.Host
headers = c.headers('Chrome')
sources = []

def get_stream(host_list):
    streams = None
    for host in host_list:
        #tools.SourceCode(host)
        if 'izanagi' in host:
            streams = izanagi(host)
        elif 'yotta' in host:
            streams = yotta(host)
        elif '_mina' in host:
            streams = mina(host)

        else:
            tools.server_detect(host)
    return streams

def mina(url):
    try:
        content = requests.get(url, headers=headers).content
        host = re.findall("\$.get\('(.*?)',", content)[0]     
        data_json = requests.get(host, headers=headers).json()
        file = data_json['file']
        if file:
            sources.append(file)
        return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def yotta(url):
    try:
        content = requests.get(url, headers=headers).content
        host = re.findall("\$.get\('(.*?)',", content)[0]
        data_json = requests.get(host, headers=headers).json()
        data_json = data_json['sources']
        for items in data_json:
            file = items['file']
            label = items['label']
            if file:
                sources.append(file)
        return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def izanagi(url):
    try:
        content = requests.get(url, headers=headers).content
        host = re.findall("\$.get\('(.*?)',", content)[0]     
        data_json = requests.get(host, headers=headers).json()
        file = data_json['file']
        if file:
            sources.append(file)
        return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e

def cartoonarabi(host):
    try:
        url = host.replace('/watch.php?','/videos.php?')
        name ='[Server : Cartoonarabi]'
        if url:
            sources.append(file)
        return sources
    except Exception, e:
        print '['+c.Addon_id+'] resolver '+c.Addon_name+' error', e