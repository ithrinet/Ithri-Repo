# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for AnimeFLV.Net
# Version 0.1

#-----------------------Codigo Util-------------------------------------
import sys
import urllib,re,urlparse
import xbmc,xbmcgui,xbmcplugin
import requests,json
#import cfscrape
import urlresolver
from bs4 import BeautifulSoup as bs
from resources.lib import tools as t
from resources.lib import common as c


BaseUrl = 'http://animeflv.net'
_Browse = '%s/browse?type[]=%s$order=default'
Headers = c.headers('Chrome')
reload(sys)
sys.setdefaultencoding('utf-8')

PluginHandle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
pdialog = xbmcgui.DialogProgress()

c.addon_data()
c.addon_temp()

def kategorien():
    addDir('Ultimos Episodios','','Ultimos','','','','','')
    addDir('Últimos animes agregados','','Recientes','','','','','')    
    addDir('Animes En Emision','','Emision','','','','','')   
    #addDir('Top Ayer','top_ayer','TOP','','','','','')
    addDir('Series','tv','SubMenu','','','','','')
    addDir('Peliculas','movie','SubMenu','','','','','')
    addDir('OVAS','ova','SubMenu','','','','','')
    addDir('Especial','special','SubMenu','','','','','')
    addDir('Buscar',BaseUrl+'search?q=','Buscar','','','','','')
    addDir('Ver Mas Tarde','','my_anime','','','','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def SubMenu():
    url = args['url'][0]
    host = _Browse % (BaseUrl,url)

    addDir('All',host,'Items','','','','','')
    #addDir('A-Z',host,'Test','','','','','&tipo=%s' % tipo)
    addDir('Genero',host,'Filter','','','','','')
    addDir('Año',host,'Filter','','','','','')
    addDir('Estado',host,'Filter','','','','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Filter():
    try:
        name = args['name'][0]
        host = args['url'][0]
        html =  t.Request(host.replace('$','&'),'')
        if name == "Genero":
            items = html.find(id="genre_select").find_all("option")
            for item in items:
                if item["value"]:
                    link = '%s$genre[]=%s'%(host,item["value"])
                    addDir(item.text,link,'Items','','','','','')

        elif name == "Año":
            items = html.find(id="year_select").find_all("option")
            for item in items:
                if item["value"]:
                    addDir(item["value"],'%s$year[]=%s'%(host,item["value"]),'Items','','','','','')

        elif name == "Estado":
            items = html.find(id="status_select").find_all("option")
            for item in items:
                if item["value"]:
                    addDir(item.string,'%s$status[]=%s'%(host,item["value"]),'Items','','','','','')

        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Filer gefunden', xbmcgui.NOTIFICATION_INFO, 5000)


def Ultimos():
    try:
        html = t.Request(BaseUrl,'')
        items = html.find(class_="ListEpisodios").find_all(class_="fa-play")

        for item in items:
            u_title = item.find(class_="Title").string
            u_eps = re.sub(r'[^\d]+','',item.find(class_="Capi").string)
            u_url = '%s%s' % (BaseUrl,item['href'])
            u_img = '%s%s' % (BaseUrl,item.img['src'].replace('/thumbs/','/covers/'))
            name = '[COLOR blue]%s[/COLOR] - [COLOR orange]%03d[/COLOR]' % (u_title,int(u_eps)) if u_eps.isdigit() else '[COLOR blue]%s[/COLOR] - [COLOR orange]%s[/COLOR]' % (u_title,u_eps)
            
            cm=[]
            u=sys.argv[0]+"?url="+u_url+"&cover="+u_img+"&name="+name+"&type="+'tipo'+"&mode="+'add_to_my_anime'
            cm.append( ('Add To My Anime', "XBMC.RunPlugin(%s)" % u))
            addLink(name,u_url,'Stream',u_img,'','','','',cm=cm)
        xbmcplugin.setContent(PluginHandle, 'tvshows')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Neue Episoden Gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Recientes():
    try:
        html = t.Request(BaseUrl,'')

        items = html.find(class_="ListAnimes").find_all(class_="Anime alt B")
        for item in items:
            title = item.h3.string
            url = '%s%s' % (BaseUrl,item.a['href'])
            img = '%s%s' % (BaseUrl,item.img['src'])
            tipo = item.find(class_="Type").string
            plot = item.find_all("p")[1].string
            
            name = '[COLOR orange]%s[/COLOR] - [COLOR blue]%s[/COLOR]' % (tipo,title)
            #plot,genero,votos = Info(url)

            data = '&tipo=%s' % tipo
            cm=[]
            u=sys.argv[0]+"?url="+url+"&cover="+img+"&name="+name+"&type="+tipo+"&mode="+'add_to_my_anime'
            cm.append( ('Add To My Anime', "XBMC.RunPlugin(%s)" % u))

            addDir(name,url,'Episodes',img,plot,'','','',cm=cm)

        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Anime gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Emision():
    items = t.Request(BaseUrl,'').find(class_="ListSdbr").find_all("a")
    for item in items:
        title = '[COLOR blue]%s[/COLOR]' % item.contents[0]
        url = "%s%s" % (BaseUrl,item['href'])
        tipo = item.span.string
        #img = "%s/uploads/animes/covers/%s.jpg" % (BaseUrl,re.findall('/anime/(.*?)/',item['href'])[0])
        #t.SourceCode(img)
        addDir(title,url,'Episodes','','','','','')
    xbmcplugin.setContent(PluginHandle, 'tvshows')
    xbmcplugin.endOfDirectory(PluginHandle)

def Items():
    try:
        host = args['url'][0].replace('$','&')
        html = t.Request(host,'')
        items = html.find_all("article",class_="Anime alt B")
        pages = html.find(class_="pagination")

        if items:
            for item in items:
                title = item.h3.string if item.h3.string else item.img['alt']
                url = '%s%s' % (BaseUrl,item.a['href'])
                cover = item.img['src']
                tipo = item.span.string
                plot = item.find_all("p")[1].string

                cm=[]
                u=sys.argv[0]+"?url="+url+"&cover="+cover+"&name="+title+"&tipo="+tipo+"&mode="+'add_to_my_anime'
                cm.append( ('Add To My Anime', "XBMC.RunPlugin(%s)" % u))

                addDir(title,url,'Episodes',cover,plot,'','','','')

            if pages.find(rel="next"):
                if pages.find(rel="next")['href'] != "#":
                    pages = pages.find(rel="next")
                    url = '%s%s' % (BaseUrl,pages['href'].replace('&','$'))
                    page = url.split('page=')[1]
                    title = '[COLOR blue]Next Page: %s[/COLOR]' % page
                    addDir(title,url,'Items','','','','','')

            xbmcplugin.setContent(PluginHandle, 'movies')
            xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Anime gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Episodes():
    try:
        import ast
        host = args['url'][0]
        img = args['iconimage'][0]

        html = t.Request(host,'')
        data_js = html.find_all('script', type="text/javascript")
        
        data_js = [word for word in data_js if "anime_info" in str(word)][0]

        anime_info = ast.literal_eval(re.findall('anime_info = (.*?);',str(data_js))[0])
        episodes = ast.literal_eval(re.findall('episodes = (.*?);',str(data_js))[0])

        anime_id = anime_info[0]
        anime_name = anime_info[1]
        anime_url = anime_info[2]
        anime_date = anime_info[3] if len(anime_info)== 4 else ''

        for item in episodes:
            eps = item[0]
            eps_id = item[1]
            url = "%s/ver/%s/%s-%s" % (BaseUrl,eps_id,anime_url,eps)
            eps_img = "%s/uploads/animes/screenshots/%s/%s/th_3.jpg" % (BaseUrl,anime_id,eps)
            cover = "%s/uploads/animes/covers/%s.jpg" % (BaseUrl,anime_id)
            fanart = "%s/uploads/animes/thumbs/%s.jpg" % (BaseUrl,anime_id)
            name = '[COLOR blue]%s[/COLOR] - [COLOR orange]%03d[/COLOR]' % (anime_name,int(eps))
            cm=[]
            u=sys.argv[0]+"?url="+url+"&cover="+cover+"&name="+name+"&type="+'tipo'+"&mode="+'add_to_my_anime'
            cm.append( ('Add To My Anime', "XBMC.RunPlugin(%s)" % u))
            addLink(name,url,'Stream',eps_img,'','','','',cm=cm)
        xbmcplugin.setContent(PluginHandle, 'episodes')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: keine Episode gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Buscar():
    try:
        kb = xbmc.Keyboard ('', 'Suche %s' % c.Addon_name, False)    
        kb.doModal()
        if (kb.isConfirmed() and kb.getText() !=''):
            host = '%s/browse?q=%s' % (BaseUrl,kb.getText())

            items = t.Request(host,'').find_all(class_="Anime alt B")
            for item in items:
                title = item.h3.string
                img = item.img['src']
                url = "%s%s" % (BaseUrl,item.a['href'])
                tipo = item.span.string                
                #info = Info(url)
                #data = '&tipo=%s' % tipo
                name = '[COLOR red]%s[/COLOR] - [COLOR blue]%s[/COLOR]' % (tipo,title)
                addDir(name,url,'Episodes',img,'','','','')

            xbmcplugin.setContent(PluginHandle, 'tvshows')
            #xbmc.executebuiltin('Container.SetViewMode(%s)'% VIEWS)
            xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Resultat', xbmcgui.NOTIFICATION_INFO, 5000)

def Stream():
    try:
        title = args['name'][0]
        #tipo = args['tipo'][0]
        host = args['url'][0]
        img = args['iconimage'][0]
        file = ""
        server_name = []
        server_url = []

        html = t.Request(host,'')

        items = html.find(role="tablist").find_all('li')
        javascript = html.find_all('script', type="text/javascript")

        index = 0
        for js in javascript:        
            if 'video[0]' in str(js):
                for item in items:
                    index += 1
                    data_id = item['data-id']
                    ser_name = item['title']
                    ser_ifr = re.findall('video\[%s\] = (.*?);' % data_id,str(js),re.DOTALL)[0]

                    if "iframe" in ser_ifr:
                        url = bs(ser_ifr,'html.parser').find('iframe')['src']
                        name = '%02d | %s' % (index,ser_name.title())
                        server_name.append(name)
                        server_url.append(url)

        ret = dialog.select('Select Server: %s'% title,server_name)

        if len(server_url) > 1 :
            if ret != -1 and urlresolver.HostedMediaFile(link).valid_url():
                url = server_url[ret]

                if 'embed.php' in url:
                    link = url.replace('embed.php','check.php')
                    data_jsn = requests.get(link,headers=Headers).json()
                    #t.SourceCode(data_jsn)
                    file = data_jsn['file']
                else:
                    url = re.findall('ion.href.*?"(.*?)"',requests.get(url,headers=Headers).content)[0]
                    file = urlresolver.resolve(url)
            else:
                pass
        else:
            file = urlresolver.resolve(server_url[0])

        if file:
            listitem = xbmcgui.ListItem(path = file)
            listitem.setInfo( type="video", infoLabels={ "title": title } )
            listitem.setArt({ 'fanart': img,'poster': img,'banner' : img })          
            xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein file gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

#---------------------------------------Codigo importante-------------------------------------

def addLink(name,url,mode,iconimage,plot,rating,genero,data,cm=False):
    fanart = iconimage.replace('/covers/','/banners/')
    infoLabels={ "title": name, "Plot": plot,'genre': genero,
                "rating": rating
        }

    u=sys.argv[0]+"?url="+url+"&mode="+mode+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : fanart })
    item.setInfo( type="Video", infoLabels=infoLabels )
    item.setProperty('IsPlayable', 'true')
    #item.addStreamInfo('video', { 'duration' : '300' })
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)

def addDir(name,url,mode,iconimage,plot,rating,genero,data,cm=False):
    fanart = iconimage.replace('/covers/','/banners/')
    
    #infoLabels={ "title": name, "Plot": plot,"Genre": genre,"rating": rating}

    labels = {'title': name,'sorttitle': name,'genre': genero,'studio': 'Ithrinet','director':'Ithrinet',
        'duration': '','plot': plot,'episode': '','rating': rating
        }

    u=sys.argv[0]+"?url="+url+"&mode="+mode+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : fanart })
    item.setInfo( type="Video", infoLabels=labels )
    if cm:
        item.addContextMenuItems( cm )

    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)



#-----------------------------------Funciones-------------------------------------------

def my_anime():
    entries = t.get_my_anime()
    try:
        for entry in entries:
            title = entry['title']            
            url = entry['url']
            try:
                cover = entry['cover']
                type = entry['type']
            except:
                cover = ''
                type = ''
            cm = []
            u3=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&name="+urllib.quote_plus(title)+"&mode="+urllib.quote_plus('remove_my_anime')
            cm.append( ('Delete From My Anime', "XBMC.RunPlugin(%s)" % u3) )
            if type =='Folgen':
                addLink(title,url,'Streams',cover,'','','','',cm=cm)
            else:
                addDir(title,url,'Folgen',cover,'','','','',cm=cm)

        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        #xbmc.executebuiltin('Notification(Keine Anime)')
        dialog.notification(c.Addon_name, 'Info: Kein Anime gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Info(host):
    html = t.Request(host,'')
    plot = html.find(class_="Description").p.string
    genero = (', '.join(re.findall('\?genre=(.*?)"',str(html.find(class_="Nvgnrs")))))
    votos = html.find(id="votes_prmd").string

    #genero = [item.content for item in html.find(class_="Nvgnrs").find_all("a")]
    #fanart = BaseUrl + html.find(class_="Bg")['style'].split('background-image:url(')[1].split(')')[0]
    #cover = BaseUrl + html.find(class_="Image").img['src']

    return plot,genero,votos

def add_to_my_anime():
    try:
        type = args['type'][0]
        title = args['name'][0]
        url = args['url'][0]
        cover = args['cover'][0]
        t.set_my_anime(type,title,url,cover)
    except: pass

def remove_my_anime():
    try:
        url = args['url'][0]
        t.remove_my_anime(url)
    except: pass

def remove_history():
    key = args['name'][0]
    url = args['url'][0]
    try: 
        t.remove_history(key,url)
    except: pass

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    kategorien()
else:
    exec '%s()' % mode[0]