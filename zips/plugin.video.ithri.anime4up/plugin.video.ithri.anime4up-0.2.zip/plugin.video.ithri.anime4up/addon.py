# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on
# Version 0.2

import sys
import re,urlparse
import xbmc,xbmcgui,xbmcplugin
import requests,urlresolver,resolveurl
from resources.lib import tools as t
from resources.lib import common as c

reload(sys)
sys.setdefaultencoding('utf-8')

dialog = xbmcgui.Dialog()
pdialog = xbmcgui.DialogProgress()

PluginHandle = int(sys.argv[1])

Headers = c.headers('Chrome')

_Host = 'https://ww.anime4up.com'

c.addon_data()
c.addon_temp()


def Menu():
    addDir('Episode Update','episode','Latest','','','','')
    addDir('Top Anime','','Fixed','','','','')
    #addDir('Latest Update','','Letzte','','','','')
    #addDir('Animes','%slist_anime_online'% _Host,'Items','','','','')
    #addDir('Movies','%sseries_online_type/ﻢﻠﻴﻓ/'% _Host,'Items','','','','')
    #addDir('Ovas','%sseries_online_type/ﺎﻓﻭا/'% _Host,'Items','','','','')
    #addDir('Onas','%sﺎﻧﻭا/'% _Host,'Items','','','','')
    addDir('Search','?search_param','Search','','','','')
    #addDir('My Liste','','Perfil','','','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Search():
    #try:
        url = '%s/%s' % (_Host,'?search_param=animes&s=')
        kb = xbmc.Keyboard ('', 'Suche %s' % c.Addon_name, False)    
        kb.doModal()
        if (kb.isConfirmed() and kb.getText() !=''):
            url = '%s%s' % (url,kb.getText())

            #Items = t.Request(url,'').find_all(class_="anime-block")
            Items = t.Request(url,'').find_all(class_="anime-card-container")
        
            for item in Items:
                title = item.h3.string
                cover = item.img['src'].replace('?resize=215%2C300&ssl=1','') if "<img" in str(item) else ""
                href = item.a['href']
                an_type = item.find(class_="anime-card-type").a.string
                plot = item.find(class_="anime-card-title")['data-content']
                #name = '%s -%s' % (title,'')

                addDir(title,href,'Episodes',cover,'',plot,'')
            xbmcplugin.setContent(PluginHandle, 'movies')
            xbmcplugin.endOfDirectory(PluginHandle)
    #except:
        #dialog.notification(c.Addon_name, 'Info: Kein Resultat gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Latest():
    #try:
        title = args['name'][0]
        url = '%s/%s' % (_Host,args['url'][0])        

        data_items = t.Request(url,'').find_all(class_="anime-card-container")

        for item in data_items:

            title = item.img['alt']
            episode = item.a.string.replace('الحلقة','').replace('الأوفا','').replace('الأونا','').strip()
            href = item.a['href']
            plot = item.find(class_="anime-card-title")['data-content']
            cover = item.img['src'].replace('?resize=215%2C300&ssl=1','') if "<img" in str(item) else ""

            name = '%s - [COLOR orange]%03d[/COLOR]' % (title,int(episode))
            addLink(name,href,'Stream',cover,'',plot,'')
        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)

def Latest1():
    #try:
        Items = t.Request(_Host,'').find_all(class_="episodes-list-content")[0].find_all(class_="episodes-card-container")


        for item in Items:
            ep = item.h3.string.replace('Ø§ÙØ­ÙÙØ©','').strip()
            #title = item.img['alt']
            title = item.find(class_="ep-card-anime-title").h3.string
            cover = item.img['src'].replace('?resize=270%2C165&ssl=1','') if "<img" in str(item) else ""
            href = item.a['href']
            #an_type = item.find(class_="anime-card-type").a.string
            plot = 'Esto es Parueba'#item.find(class_="anime-card-title").

            title = '%s - %s' % (title,ep)
            addLink(title,href,'Stream',cover,'',plot,'')
        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)

def Fixed():
    #try:
        #title = args['name'][0]
        #href = args['url'][0]

        Items = t.Request(_Host,'').find_all(class_="owl-carousel owl-animes")[0].find_all(class_="anime-card-container")
        
        for item in Items:
            title = item.h3.string
            cover = item.img['src'].replace('?resize=215%2C300&ssl=1','') if "<img" in str(item) else ""
            href = item.a['href']
            an_type = item.find(class_="anime-card-type").a.string
            plot = item.find(class_="anime-card-title")['data-content']
            #name = '%s -%s' % (title,'')

            addDir(title,href,'Episodes',cover,'',plot,'')
        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    #except:
        #dialog.notification(c.Addon_name, 'Info: Kein Neuen Episoden gefunden', xbmcgui.NOTIFICATION_INFO, 5000)
    
def Items():
    #try:
        title = args['name'][0]
        href = args['url'][0]
        html_data = t.Request(href,'')


        Items = html. find_all(class_="anime-block")
        next_page = html.find(class_="next page-numbers")

        for item in Items:
            #break
            _title = item.find(class_="anime-title-list").string

            link = item.find_all("a")[1]['href'] if title == "Animes" else item.find_all("a")[2]['href']

            cover = item.img['src'].replace('-290x330','') if "<img" in str(item) else ""

            #plot = item.find(class_="anime-content").text
            year = item.find(class_="anime-date").find("a").text
            genres = t.get_genres(item.find(class_="anime-genre"))

            info = t.Request(link,'')
            plot = info.find(class_="ES_content").strong.string if "strong" in str(info.find(class_="ES_content")) else ""
            
            name = '%s' % re.sub(r'[^a-zA-Z0-9\s\-\:]','',_title)
            addDir(name,link,'Episodes',cover,genres,plot,year)

        if next_page:
            link = next_page['href']
            page_num = 'Next Page: %s' % link.split('page/')[1].split('/')[0]
            addDir(page_num,link,'Items','','','','')


        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    #except:
        #dialog.notification(c.Addon_name, 'Info: Kein Anime gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Episodes():
    #try:
        title = args['name'][0]
        href = args['url'][0]
        cover = args['iconimage'][0]
        genres = []

        html_data = t.Request(href,'')
        anime_info = html_data.find_all(class_="anime-info")

        desc = html_data.find(class_="anime-story").string
        year = anime_info[1].text.replace('Ø¨Ø¯Ø§ÙØ© Ø§ÙØ¹Ø±Ø¶:','').strip()

        for item in html_data.find(class_="anime-genres").find_all('a'):
            genres.append(item.string)

        Items = html_data.find(id="DivEpisodesList").find_all(class_="episodes-card")
        Items.sort(reverse=True)

        for item in Items:
            ep = item.h3.string.replace('Ø§ÙØ­ÙÙØ©','').strip()
            href = item.h3.a['href']
            img = item.img['src'].replace('?resize=270%2C165&ssl=1','')
            name = '%s - %s' % (title,ep)
            
            addLink(name,href,'Stream',img,genres,desc,year)
        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    #except:
        #dialog.notification(c.Addon_name, 'Info: Kein Episoden gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Stream():
    try:
        href = args['url'][0]
        title = args['name'][0]
        cover = args['iconimage'][0]
        server_name = []
        hoster_url = []
        genres = []

        html_data = t.Request(href,'')
        quality_list = html_data.find_all(class_="quality-list")
        stream_servers = html_data.find(id="episode-servers").find_all('li')

        anime_data = html_data.find(class_="anime-details")
        anime_info = anime_data.find_all(class_="anime-info")

        desc = anime_data.p.string
        year = anime_info[1].text.replace('بداية العرض: ','')
        

        for item in anime_data.ul.find_all('a'):
            genres.append(item.string)

        
        for item in stream_servers:

            if urlresolver.HostedMediaFile(item.a['data-ep-url']).valid_url():
                server_name.append(item.a.string)
                hoster_url.append(item.a['data-ep-url'])

        '''
        for quality in quality_list:
            Items = quality.find_all('li')
            name = Items[0].string
            Items.pop(0)        

            for item in Items:

                if 'FHD' in name:
                    qu_name = 'Quality FHD'
                    name = '%s - %s' % ('FHD',item.a.string.title())
                    server_name.append(name)
                    hoster_url.append(item.a['href'])

                elif 'HD' in name:
                    qu_name = 'Quality HD'
                    name = '%s - %s' % ('HD',item.a.string.title())
                    server_name.append(name)
                    hoster_url.append(item.a['href'])
            ster_url.append(item.a['href'])
            
        '''
        
        ret = dialog.select("Select Server - %s" %  title,server_name)
        hoster = hoster_url[ret]
        #t.SourceCode(hoster)


        if urlresolver.HostedMediaFile(hoster):
            file = resolveurl.resolve(hoster)

        elif resolveurl.HostedMediaFile(hoster):
            file = urlresolver.resolve(hoster)

        infoLabels = { "Title": title,"Plot":desc,"year": year,"genre": genres,
                    "episode": 04,"sortepisode": 04,"rating": 6.4,"playcount": 5222,"mpaa": "PG-13"
                }

        listitem = xbmcgui.ListItem(path = file,iconImage=cover, thumbnailImage=cover) 
        listitem.setInfo( type="video", infoLabels = infoLabels )            
        xbmcplugin.setResolvedUrl(PluginHandle, True, listitem) 
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Servers', xbmcgui.NOTIFICATION_INFO, 5000)
#--------------------------------------------Codigo Importante------------------------------------------



def addDir(name,url,mode,iconimage,genres,plot,year,cm=False):    
    fanart = iconimage.replace('-220x300','')
    labels = {'title': name,'sorttitle': name,'genre': genres,'year': year,'director':'ithrinet',
        'duration': '','plot': plot,'episode': '','rating': 9.9 
        }

    u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels=labels )
    if cm:
        item.addContextMenuItems( cm )

    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)

def addLink(name,url,mode,iconimage,genres,plot,year,cm=False):
    fanart = iconimage.replace('-220x300','')
    labels = {'title': name,'sorttitle': name,'genre': genres,'year': year,'director':'ithrinet',
        'duration': '','plot': plot,'episode': '','rating': 9.9

        }

    u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels=labels )
    item.setProperty('IsPlayable', 'true')
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)



args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    Menu()
else:
    exec '%s()' % mode[0]