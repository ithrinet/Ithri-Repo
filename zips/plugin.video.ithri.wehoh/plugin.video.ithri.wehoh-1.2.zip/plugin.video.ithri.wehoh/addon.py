# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on
# Version 0.1

import sys
import re,urlparse, xbmcgui,xbmcplugin
from resources.lib import tools as t
from resources.lib import common as c

reload(sys)
sys.setdefaultencoding('utf-8')
dialog = xbmcgui.Dialog()
Headers = c.headers('Chrome')

PluginHandle = int(sys.argv[1])

tmdb_base = 'https://api.themoviedb.org/3'
tmdb_key = '2ab10ff6afda491d22e70604dbdc6442'
tmdb_query = 'query=%s'
tmdb_lang = 'language=%s' # Ejemplo es-Es, ar-SA, ar-EA, de
tmdb_img = 'https://image.tmdb.org/t/p/original'

def Menu():
    addDir('Ultimos Episodios','%s/%s'% (c.BaseUrl,'episode'),'Ultimos','','','','')
    addDir('Episodios Destacados','','Destacados','','','','')
    #addDir('Animes Mas Visotos','owl-most-viewed-animes','Ultimos','','','','')
    addDir('Animes','tv','SubMenu','','','','')
    addDir('Peliculas','movie','SubMenu','','','','')
    addDir('OVA','ova','SubMenu','','','','')
    addDir('ONA','ona','SubMenu','','','','')
    addDir('Special','special','SubMenu','','','','')
    addDir('Search','','Search','','','','')
    #addDir('My Liste','','Perfil','','','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def SubMenu():
    link = args['url'][0]
    data = "&_type=%s" % link
    url = '%s/anime-type/%s' % (c.BaseUrl,link)

    addDir('All',url,'Items','','','',data)
    addDir('A-Z',url,'Category','','','',data)    
    addDir('Genres',url,'Category','','','',data)
    addDir('Translators',url,'Category','','','',data)
    addDir('State',url,'Category','','','',data)

    xbmcplugin.endOfDirectory(PluginHandle)

def Category():
    try:
        name = args['name'][0]
        url = args['url'][0]    
        _type = args['_type'][0]
        #url = '%s/anime-type/%s' % (c.BaseUrl,link)

        html = t.Request(url,'').find_all(class_="dropdown-menu scrollable-menu")
        data = "%s&_type=%s" % ('',_type)

        if name == 'A-Z':
            url = '%s/en-anime-letter/%s'

            addDir('#',url % (c.BaseUrl,'28'),'Items','','','',data)
            for item in c.Alphabet:
                addDir(item,url % (c.BaseUrl,item),'Items','','','',data)

        elif name == 'State':
            addDir('in Emission',c.BaseUrl+'/anime-status/%d9%8a%d8%b9%d8%b1%d8%b6-%d8%a7%d9%84%d8%a2%d9%86/','Items','','','',data)
            addDir('Finalized',c.BaseUrl+'/anime-status/%d9%85%d9%83%d8%aa%d9%85%d9%84/','Items','','','',data)

        elif name == 'Genres':
            genres = html[1].find_all("li")
            for item in genres:
                gener = item.a.string
                href = item.a['href']
                addDir(gener,href,'Items','','','',data)

        elif name == 'Translators':
            transls = html[5].find_all("li")
            for item in transls:
                addDir(item.a.string,item.a['href'],'Items','','','',data)

        xbmcplugin.endOfDirectory(PluginHandle)

    except:
        dialog.notification(c.Addon_name, 'Info: Kein Category', xbmcgui.NOTIFICATION_INFO, 5000)

def Destacados():
    try:
        name = args['name'][0]

        html = t.Request(c.BaseUrl,'')
        items = html.find(id="pin-episode-paginate").findChildren("article" , recursive=False)#.find_all(class_="episodes-card")

        for item in items:
            title = item.find_all("h3")[1].a.string
            title = title.strip() if title else re.sub(r'[^a-zA-Z\s@:!]+','',item.img['alt']).strip()
            eps = re.sub(r'[^\d\w\s-]+','',item.a.string).strip()
            url = item.a['href']        
            img = item.img['src'].replace('-270x165','')
            plot = ''


            # Funciones de TMDB
            #tmdb_url = '%s/search/tv?api_key=%s&query=%s&language=ar' % (tmdb_base,tmdb_key,title)

            #tmdb_json = t.Requests.get(tmdb_url,headers=Headers).json()
            #tmdb_result = tmdb_json['results']
            #tmdb_total = tmdb_json['total_results']
            '''

            if tmdb_result:
                result = tmdb_result[0]
                #name = result['name']
                #name_org = result['original_name']
                img = '%s/%s' % (tmdb_img,result['poster_path'])
                fanart = '%s/%s' % (tmdb_img,result['backdrop_path'])
                plot = result['overview']

            else:
                #name = title
                img = item.img['src'].replace('-270x165','')
                fanart = item.img['src'].replace('-270x165','')
                plot = '''
            name = '[COLOR blue]%s[/COLOR] - [COLOR orange]%03d[/COLOR]' % (title,int(eps)) if eps.isdigit() else '[COLOR blue]%s[/COLOR] - [COLOR orange]%s[/COLOR]' % (title,eps)
            addLink(name,url,'Stream',img,img,plot,'')

        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)

    except:
        dialog.notification(c.Addon_name, 'Info: Kein Destacados', xbmcgui.NOTIFICATION_INFO, 5000)

def Ultimos():
    try:
        name = args['name'][0]
        url = args['url'][0]
        html = t.Request(url,'')

        items = html.find_all(class_="am-card")
        for item in items:
            a = item.find_all("a")[1]
            title = item.h3.a.string
            title = title.strip() if title else item.img['alt'].strip()
            url = a['href']        
            eps = re.sub(r'[^\d\w\s-]+','',a.string).strip()
            img = item.img['src'].replace('-215x300','')
            type_name = item.find(class_="am-card-type").a.string

            name = '[COLOR blue]%s[/COLOR] - [COLOR orange]%03d[/COLOR]' % (title,int(eps)) if eps.isdigit() else '[COLOR blue]%s[/COLOR] - [COLOR orange]%s[/COLOR]' % (title,eps)
            addLink(name,url,'Stream',img,'','','')
        
        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)

    except:
        dialog.notification(c.Addon_name, 'Info: Kein Episoden', xbmcgui.NOTIFICATION_INFO, 5000)

def Search():
    try:
        import xbmc
        url = '%s/?s=%s&search_param=%s'
        kb = xbmc.Keyboard ('', 'Suche %s' % c.Addon_name, False)    
        kb.doModal()
        if (kb.isConfirmed() and kb.getText() !=''):
            items = t.Request(url % (c.BaseUrl,kb.getText(),'animes'),'').find_all(class_="am-card")
        
            for item in items:
                #addDir(item.img['alt'],item.a['href'],'Episodes',item.img['src'],'','')
                addDir(item.h3.a.string,item.h3.a['href'],'Episodes',item.img['src'].replace('-215x300',''),'','','')
            xbmcplugin.setContent(PluginHandle, 'movies')
            xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Resultat', xbmcgui.NOTIFICATION_INFO, 5000)


def Items():
    try:
        url = args['url'][0]
        _type = args['_type'][0]

        html = t.Request(url,'')
        items = html.find_all('div',class_="am-card")
        #pagins = html.find(class_="pagination-content")
        #if "fansub" in url:        
            #items = list(set(items))
        if _type in str(items):
            for item in items:
                title = item.h3.a.string
                title = title if title else item.img['alt']
                url = item.h3.a['href']
                cover = item.img['src']
                i_type = item.find(class_="am-card-type").a.string

                if _type.upper() == i_type.upper():
                    addDir(title.strip(),url,'Episodes',cover.replace('-215x300',''),'','','')

            xbmcplugin.setContent(PluginHandle, 'movies')
            xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Animes', xbmcgui.NOTIFICATION_INFO, 5000)

def Episodes():
    try:
        url = args['url'][0]
        title = args['name'][0]
        logo = args['iconimage'][0]
        
        html = t.Request(url,'')
        items = html.find_all(class_="episodes-card")

        #items.reverse()
        if items:
            for item in items:
                eps = re.sub(r'[^\d\w\s-]+','',item.a.string).strip()
                url = item.a['href']
                logo = item.img['src'].replace('-270x165','')
                name = '[COLOR blue]%s[/COLOR] - [COLOR orange]%03d[/COLOR]' % (title,int(eps)) if eps.isdigit() else '[COLOR blue]%s[/COLOR] - [COLOR orange]%s[/COLOR]' % (title,eps)
                #title = item.find(class_="ep-card-anime-title").a.string

                addLink(name,url,'Stream',logo,'','','')
            xbmcplugin.endOfDirectory(PluginHandle)
        else:
            dialog.notification(c.Addon_name, 'Info: Kein Episodes gefunden', xbmcgui.NOTIFICATION_INFO, 5000)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Episoden', xbmcgui.NOTIFICATION_INFO, 5000)

def Stream():
    try:
        import urlresolver
        url = args['url'][0]
        title = args['name'][0]
        img = args['iconimage'][0]

        server_name = []
        server_url = []

        data_html = t.Request(url,'').find(class_="col-md-9")
        translatars = data_html.find(class_="watch-option").find_all("a")
        items = data_html.find_all("iframe")

        index = 0
        for trans in translatars:

            if "href" in str(trans):
                trans_href = trans["href"].replace('#','')
                trans_name = trans.text

                data_trans = data_html.find(id=trans_href)
                sers_trans = data_trans.find("ul",class_="nav nav-tabs").find_all("a")

                for sers in sers_trans:
                    
                    ser_href = sers['href'].replace('#','')
                    ser_name = sers.text

                    data_servs = data_trans.find(id=ser_href).find_all("iframe")

                    for item in data_servs:
                        index += 1

                        name = '%02d | [B]%s[/B] | %s' % (index,trans_name.title(),ser_name.title())
                        link = item["src"]

                        if link:
                            server_url.append(link)
                            server_name.append(name)

        if len(server_url) > 1 :
            ret = dialog.select('Select Server : %s' % title,server_name)
            file = urlresolver.resolve(server_url[ret])

        else:
            file = urlresolver.resolve(server_url[0])

        if file:
            listitem = xbmcgui.ListItem(path=file,iconImage=img, thumbnailImage=img) 
            listitem.setInfo( type="video", infoLabels={ "title": title } )            
            xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Streams Links gefunden', xbmcgui.NOTIFICATION_INFO, 5000)


#------------------------------------------Codigo Antigou--------------------------

def addDir(name,url,mode,iconimage,fanart,plot,data,cm=False):
    u = "%s?mode=%s&url=%s&name=%s&iconimage=%s&data=%s" % (sys.argv[0],mode,url,name,iconimage,data)
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot} )
    if cm:
        item.addContextMenuItems( cm )

    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)

def addLink(name,url,mode,iconimage,fanart,plot,data,cm=False):
    u = "%s?mode=%s&url=%s&name=%s&iconimage=%s&data=%s" % (sys.argv[0],mode,url,name,iconimage,data)
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot} )
    item.setProperty('IsPlayable', 'true')
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)



args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    Menu()
else:
    exec '%s()' % mode[0]