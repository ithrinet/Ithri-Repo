# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Rifalbum.com
# Version 0.1

import os,re
import requests
from resources.lib import common as c
from bs4 import BeautifulSoup as bs


Headers = c.headers('Chrome')
session = requests.Session()

def get_thumbs (img):
    return os.path.join(c.Addon_thumbs,img)

def trans(string):
    return c.Translations(string).encode("utf-8")

def SourceCode(content):
    File = open(c.HTMLData,'a')
    File.write(str('%s \n' % content))
    File.close()

def get_domain(url):
    m = re.match('((https?):\/\/)?(\w+\.)*(?P<domain>\w+)\.(\w+)(\/.*)?', url)
    if m:
        domain = m.group('domain')
        return domain
    else:
        return False

def Request(host,data):
    if data == "html5":
        rq = session.get(host,headers=Headers)
        sp = bs(rq.content,'html5lib')
    else:
        rq = session.get(host,headers=Headers)
        sp = bs(rq.content,"html.parser")
    return sp
