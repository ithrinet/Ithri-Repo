# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Rifalbum.com
# Version 0.1

import xbmc,xbmcaddon,xbmcgui
import requests
import os,re
import json

Addon     = xbmcaddon.Addon()
Addon_name = Addon.getAddonInfo('name')
Addon_author = Addon.getAddonInfo('author')
Addon_version = Addon.getAddonInfo('version')
Addon_id = Addon.getAddonInfo('id')
Addon_profile = Addon.getAddonInfo('profile')

Addon_data = xbmc.translatePath(Addon_profile).decode("utf-8")
Addon_path = xbmc.translatePath(Addon.getAddonInfo('path')).decode("utf-8")
Addon_resources = os.path.join(Addon_path,'resources')
Addon_temp = os.path.join(Addon_data,'temp')
Addon_thumbs = os.path.join(Addon_resources,'media')

history = os.path.join(Addon_temp,'search.json')
my_anime = os.path.join(Addon_temp,'meine.json')
HTMLData = os.path.join(Addon_path,'HTMLData.html')
thumbnail = os.path.join(Addon_temp,'thumbnail.json')
servers = os.path.join(Addon_temp,'server.txt')
JSONData = os.path.join(Addon_temp,'JSONData.json')
alphabet_json = os.path.join(Addon_temp,'alphabet.json')
m3u_file = os.path.join(Addon_path,'list.m3u')

Translations = Addon.getLocalizedString

def headers(string):
    if string == 'Chrome':
        USER_AGENT = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36'}
    elif string == 'Explorer':
        USER_AGENT = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'}
    elif string == 'Firefox':
        USER_AGENT = {'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'}
    elif string == 'Opera':
        USER_AGENT = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36 OPR/34.0.2036.50'}
    elif string == 'IOS':
        USER_AGENT = {'User-Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'}
    elif string == 'Android':
        USER_AGENT = {'User-Agent':'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'}
    return USER_AGENT

def addon_data():
    if not os.path.isdir(Addon_data):
        os.mkdir(Addon_data)

def addon_temp():
    if not os.path.isdir(Addon_temp):
        os.mkdir(Addon_temp)

def get_timeout():
    timeout = 5
    try: timeout = int(timeout)
    except: timeout = None
    return timeout