# -*- coding: utf-8 -*-
# Module: default
# Author: Ithrinet Dev
# Created on: 15.10.2017
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys,urllib2
import urllib,re,urlparse, json
import xbmc,xbmcgui,xbmcplugin
from resources.lib import tools as t
from resources.lib import common as c
import requests, urlresolver
from bs4 import BeautifulSoup as bs

reload(sys)
sys.setdefaultencoding('utf-8')

dialog = xbmcgui.Dialog()
pdialog = xbmcgui.DialogProgress()

PluginHandle = int(sys.argv[1])
c.addon_data()
c.addon_temp()

site_url = 'https://www.telemaroc.tv'
_Headers = c.headers('Chrome')



session = requests.Session()
session.get(site_url,headers=_Headers)

def Menu():
    addDir('Récemment Ajouté','0','Recent','','','')
    addDir('Moments plus Forts','1','Recent','','','')
    addDir('Émissions',"%s/emissions" % site_url,'Items','','','')
    addDir('Genres',"%s/emissions" % site_url,'Genres','','','')
    addLink('TeleMaroc Live',site_url,'LiveTV','http://img.new.livestream.com/accounts/00000000019df987/602fb570-aec9-4413-a056-f1fb77532018.png','','')
    #addDir('Derniers épisodes','رياضة-dep13.html','Items','','','')
    #addDir('Search','?s=','Search','','','')
    #https://livestream.com/accounts/27130247/events/8196478/player?width=640&height=360&autoPlay=true&mute=false
    xbmcplugin.endOfDirectory(PluginHandle)

def LiveTV():
    url = "%s/liveTV" % args['url'][0]
    #link = Request(url,'').find("iframe")['src']
    #link = "https://api.new.livestream.com/accounts/27130247/events/8196478/broadcasts/190626235.secure.m3u8?dw=80&hdnea=st=1556554029~exp=1556555829~acl=/i/27130247_8196478_lsijz8iwnvptuwul4mj_1@327915/*~hmac=7878a062ab3a51d673e03cd6ce2941cbf8ad43ddde1a654565caa1b91a42a79c"
    
    link = "plugin://plugin.video.livestream/?url=%2Flive_now&mode=104&name=&event_id=8196478&owner_id=27130247&video_id=LIVE"

    listitem = xbmcgui.ListItem(path = link,iconImage='', thumbnailImage='')
    listitem.setInfo( type="video", infoLabels={ "Title": 'TeleMaroc Live',"Plot":'TeleMaroc Live Stream' } )            
    xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)


def Recent():
    #try:
        title = args['name'][0]
        key = int(args['url'][0])
        html = Request(site_url,'')

        class_html = "resCarousel-inner" if "Forts" in title else "carousel-inner"
        title_html = "title" if "Forts" in title else "jttitle"

        Items = html.find_all(class_=class_html)[key].find_all("a")

        for item in Items:
            _title =  item.find(class_= title_html).text
            link = item['href']
            cover = item.img['src']
            name = '[COLOR blue]%s[/COLOR]' % _title
            addLink(name,link,'Streams',cover,'','')
            
        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    #except:
        #dialog.notification(c.Addon_name, 'Info: Kein Programs gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Genres():
    try:
        title = args['name'][0]
        url = args['url'][0]

        if "Genres" == title:
            #Items = ['documentaire','politique','societe','femme','jeunesse','comedie','culture','sport']
            html = Request(url,'')
            Items = html.find(role="group").find_all("a")

            for item in Items:
                genre = item.text
                href = item['href']

                if "/emission/" in href:
                    addDir(genre,href,'Episodes','','','')
                else:
                    addDir(genre,href,'Items','','','')


        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Programs gefunden', xbmcgui.NOTIFICATION_INFO, 5000)


def Items():
    try:
        title = args['name'][0]
        url = args['url'][0]

        html = Request(url,'')

        Items = html.find_all(class_="program")

        for item in Items:
            _title =  item.h2.text
            link = "%s/%s" % (site_url,item.a['href'])
            cover = item.img['src']
            #plot = item.find(class_="padding-top").text
            name = '[COLOR blue]%s[/COLOR]' % _title
            addDir(name,link,'Episodes',cover,'','')

        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Movies gefunden', xbmcgui.NOTIFICATION_INFO, 5000)



def Episodes():
    try:
        title = args['name'][0]
        host = args['url'][0]
        #plot = args['plot'][0]

        html = Request(host,'')
        plot = html.find("meta",property="og:description")['content']
        Items = html.find_all(class_="resCarousel-inner")[0].find_all("a")

        for item in Items:
            _title = item.find(class_="title").text
            link = item['href']
            cover = item.img['src']
            name = '[COLOR orange]%s[/COLOR]' % _title
            addLink(name,link,'Streams',cover,'',plot)
        #xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Episoden gefunden', xbmcgui.NOTIFICATION_INFO, 5000)



def Streams():
    try:
        title = args['name'][0]
        host = args['url'][0]
        cover = args['iconimage'][0]


        html = Request(host,'')        
        yt_url = html.find(class_="yt-iframe")['src']


        if yt_url:
            path = urlresolver.HostedMediaFile(url=yt_url).resolve()
            listitem = xbmcgui.ListItem(path = path)
            listitem.setInfo( type="Video", infoLabels={ "title": title } )            
            xbmcplugin.setResolvedUrl(PluginHandle, True, listitem=listitem)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Streams gefunden', xbmcgui.NOTIFICATION_INFO, 5000)




#--------------------------------------Codigo Antiguo-----
def Search():
    try:
        kb = xbmc.Keyboard ('', 'Suche %s' % c.Addon_name, False)    
        kb.doModal()
        if (kb.isConfirmed() and kb.getText() !=''):
            url = '%s/%s-search.html' % (site_url,kb.getText())

            Items = Request(url,'').find_all(class_="articleag2")
        
            for item in Items:
                if item.find(class_="play_videoag"):
                    _title =  t.is_title(item.find(itemprop="name").text)
                    cover = item.img['src']
                    link = "%s/%s" % (site_url,item.a['href'])
                    plot = item.find(class_="descag").text

                    name = '[COLOR blue]%s[/COLOR]' % _title
                    addLink(name,link,'Streams',cover,'',plot)
            xbmcplugin.setContent(PluginHandle, 'movies')
            xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Resultat gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Recents():
    try:
        host = args['url'][0]

        html = Request(host,'')
        Items = html.find_all(class_="articleag2")

        for item in Items:
            if item.find(class_="play_videoag"):
                _title =  t.is_title(item.find(itemprop="name").text)
                cover = item.img['src']
                link = "%s/%s" % (site_url,item.a['href'])
                plot = item.find(class_="descag").text

                name = '[COLOR blue]%s[/COLOR]' % _title
                addLink(name,link,'Streams',cover,'',plot)
        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Movies gefunden', xbmcgui.NOTIFICATION_INFO, 5000)


#--------------------------------Codigo Antiguo--------------------------



#------------------------------------------Codigo Importante------------------------------------------

def Play(name,file,cover,plot):
    try:
        
        listitem = xbmcgui.ListItem(path = file,iconImage=cover, thumbnailImage=cover) 
        listitem.setInfo( type="video", infoLabels={ "Title": name,"Plot":plot } )            
        xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Streams File gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def addDir(name,url,mode,iconimage,fanrt,plot,cm=False):

    u=sys.argv[0]+"?url="+url+"&mode="+mode+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': iconimage,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels={ "Title": name,"Plot": plot} )
    if cm:
        item.addContextMenuItems( cm )

    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)

def addLink(name,url,mode,iconimage,fanrt,plot,cm=False):

    u=sys.argv[0]+"?url="+url+"&mode="+mode+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': iconimage,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels={ "Title": name,"Plot": plot} )
    item.setProperty('IsPlayable', 'true')
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)

def Request(host,data):

    if data == "html5":
        rq = session.get(host,headers=_Headers)
        sp = bs(rq.content,'html5lib')
    else:
        rq = session.get(host,headers=_Headers)
        sp = bs(rq.content,"html.parser")

    return sp

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    Menu()
else:
    exec '%s()' % mode[0]