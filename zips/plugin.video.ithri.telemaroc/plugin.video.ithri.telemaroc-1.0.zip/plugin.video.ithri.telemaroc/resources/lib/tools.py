# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Rifalbum.com
# Version 0.1

import os,re,xbmc
import requests
import json
from resources.lib import common
headers = common.headers('Chrome')

def get_thumbs (img):
    return os.path.join(common.Addon_thumbs,img)

def trans(string):
    return common.Translations(string).encode("utf-8")

def SourceCode(content):
    File = open(common.HTMLData,'a')
    File.write(str(content)+'\n')
    File.close()

def is_title(s):
    if re.search('[a-zA-Z]', s):
        s = s.replace('مشاهدة ','').replace('فيلم ','').replace(' مترجم','').replace('مسلسل ','').replace(' لاين','')
        s = s.replace('الموسم','S ').replace('الحلقة',' ').replace('DVBRIP','').replace('أون','')
        s = s.replace('HD','').replace('DVDRip','').replace('لين','').replace('اون','').replace('مدبلج','').replace('للعربية','')
        s = s.replace('الاخيرة','').replace('الأول','1').replace('و الأخيرة','').replace('كامل و','').replace('Bluray','')
        s = s.replace('720p','').replace('الخاصة','Episode Special')
    else:
        s = s.replace('مشاهدة ','').replace('فيلم ','').replace(' مترجم','').replace('مسلسل ','').replace(' لاين','')
        s = s.replace('الموسم','موسم').replace('الحلقة','حلقة -  ').replace('DVBRIP','').replace('أون','')
        s = s.replace('HD','').replace('DVDRip','').replace('لين','').replace('اون','').replace('مدبلج','').replace('للعربية','')
        s = s.replace('الاخيرة','').replace('الأول','1').replace('و الأخيرة','').replace('كامل و','').replace('Bluray','')
        s = s.replace('720p','').replace('الخاصة','Episode Special')
    '''
    if re.search('[a-zA-Z]', title):
        title = title.replace('الموسم','Season').replace('مسلسل ','').replace('الخاصة','Special')
        title = title.replace(' مترجم','').replace('فيلم ','').replace(' مدبلج','')
        title = title.replace('سلسلة ','').replace('افلام ','').replace(' كامل','')
    else:
        title = title.replace('مشاهدة ','').replace('مسلسل ','')
        title = title.replace(' مترجم','').replace('فيلم ','').replace(' مدبلج','')
        title = title.replace('سلسلة ','').replace('افلام ','').replace(' كامل','')'''

    return s.replace('  ','')