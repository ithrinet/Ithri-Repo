# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Rifalbum.com
# Version 0.1

import re
import requests
from resources.lib import common as c
from bs4 import BeautifulSoup as bs

HEADERS = c.headers('Chrome')

def get_thumbs (img):
    return os.path.join(c.Addon_thumbs,img)

def trans(string):
    return c.Translations(string).encode("utf-8")

def SourceCode(content):
    File = open(c.HTMLData,'a')
    File.write(str(content))
    File.write('\n')
    File.close()

def get_genres(data):
    genre = ''
    gr = re.findall('tag">(.*?)</a>',str(data))
    for item in gr:
        genre += item+', '
    return genre

def Request(host,data):

    if data:
        sp = bs(data,'html.parser')
    else:
        rq = requests.get(host,headers=HEADERS)
        sp = bs(rq.text,'html.parser')
    return sp

