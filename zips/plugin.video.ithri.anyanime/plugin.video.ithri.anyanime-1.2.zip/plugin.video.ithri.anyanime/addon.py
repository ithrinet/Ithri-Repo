# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on
# Version 0.1

import sys
import re,urlparse
import xbmc,xbmcgui,xbmcplugin
import requests,urlresolver
from resources.lib import tools as t
from resources.lib import common as c

#reload(sys)
#sys.setdefaultencoding('utf-8')

dialog = xbmcgui.Dialog()
pdialog = xbmcgui.DialogProgress()

PluginHandle = int(sys.argv[1])

Headers = c.headers('Chrome')

_Host = 'http://www.anyanime.com/'

#session = requests.Session()
#session.get(_Host,headers=Headers)



c.addon_data()
c.addon_temp()


def Menu():
    addDir('Latest Update','','Latest','','','','')
    #addDir('Latest Update','','Letzte','','','','')
    addDir('Animes','%slist_anime_online'% _Host,'Items','','','','')
    addDir('Movies','%sseries_online_type/فيلم/'% _Host,'Items','','','','')
    addDir('Ovas','%sseries_online_type/اوفا/'% _Host,'Items','','','','')
    addDir('Onas','%sاونا/'% _Host,'Items','','','','')
    addDir('Search','?s=','Search','','','','')
    addDir('My Liste','','Perfil','','','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Search():
    try:
        url = '%s/%s' % (_Host,args['url'][0])
        kb = xbmc.Keyboard ('', 'Suche %s' % c.Addon_name, False)    
        kb.doModal()
        if (kb.isConfirmed() and kb.getText() !=''):
            url = '%s%s%s' % (_Host,args['url'][0],kb.getText())

            Items = t.Request(url,'').find_all(class_="anime-block")
        
            for item in Items:
                title = '[COLOR blue]%s[/COLOR]' % re.sub(r'[^a-zA-Z0-9\s\-\:]','',item.find(class_="anime-title-list").string)
                link = item.a['href']
                cover = item.img['src']
                addDir(title,link,'Episodes',cover,'','','')
            xbmcplugin.setContent(PluginHandle, 'movies')
            xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Resultat gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Latest():
    try:
        Items = t.Request(_Host,'').find_all(class_="post-media")
        for item in Items:
            title = item.find(class_="ser-title").string
            ep = re.sub(r'[^a-zA-Z0-9\s]','',item.find(class_="ep-numb").string)
            link = item.a['href']
            cover = item.a.img['src']

            #info = t.Request(link,'')
            #plot = info.find(class_="anime-content-show").strong.string if 'strong' in str(info.find(class_="anime-content-show")) else''
            #genres = t.get_genres(info.find(class_="anime-genre-show"))
            #year = info.find(class_="anime-date-show").a.string if info.find(class_="anime-date-show") else ''

            name = '[COLOR blue]%s[/COLOR] -[COLOR orange]%s[/COLOR]' % (title,ep)

            addLink(name,link,'Stream',cover,'','','')
        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Neuen Episoden gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Items():
    try:
        title = args['name'][0]
        host = args['url'][0]
        html = t.Request(host,'')

        Items = html. find_all(class_="anime-block")
        next_page = html.find(class_="next page-numbers")

        for item in Items:
            _title = item.find(class_="anime-title-list").string
            link = item.find_all("a")[1]['href']
            cover = item.img['src']
            #plot = item.find(class_="anime-content").text
            year = item.find(class_="anime-date").find("a").text
            genres = t.get_genres(item.find(class_="anime-genre"))

            info = t.Request(link,'')
            plot = info.find(class_="ES_content").strong.string if "strong" in str(info.find(class_="ES_content")) else ""
            
            name = '[COLOR blue]%s[/COLOR]' % re.sub(r'[^a-zA-Z0-9\s\-\:]','',_title)
            addDir(name,link,'Episodes',cover,genres,plot,year)

        if next_page:
            link = next_page['href']
            page_num = 'Next Page: %s' % link.split('page/')[1].split('/')[0]
            addDir(page_num,link,'Items','','','','')


        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Anime gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Episodes():
    try:
        title = args['name'][0].replace('  ','')
        host = args['url'][0]
        cover = args['iconimage'][0]
        
        url = t.Request(host,'').find(class_="down-ser").a['href']

        Items = t.Request(url,'').find(class_="list").find_all("a")
        for item in Items:
            link = item['href']
            ep_num = item.find(class_="ep_nums").string
            name = '%s - [COLOR orange]%s[/COLOR]' % (title,ep_num)

            addLink(name,link,'Stream',cover,'','','')
        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Episoden gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Stream():
    #try:
        host = args['url'][0]
        title = args['name'][0]
        cover = args['iconimage'][0]
        server_id = []
        server_name = []

        html = t.Request(host,'')
        desc = html.find(class_="anime-content-show").strong.string if "strong" in str(html.find(class_="anime-content-show")) else ""
        year = html.find(class_="anime-date-show").a.text if "<a" in str(html.find(class_="anime-date-show")) else ""
        genre = t.get_genres(html.find(class_="anime-genre-show"))

        link = "https://ww3.anyanime.com/view_online"
        Headers.update({
                'Host' : 'ww3.anyanime.com',
                'Accept' : '*/*',
                'Accept-Encoding' : 'gzip, deflate',
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With' : 'XMLHttpRequest'
            })

        
        anime_id = html.find("link",rel="shortlink")['href'].split('?p=')[1]
        
        Items = html.find_all(class_="get_it")
        index = 0

        for item in Items:
            index += 1
            sr_name = item.string.strip()
            name = '%02d | [B]%s[/B]' % (index,sr_name.title())
            server_name.append(name)
            server_id.append(item['id'])

        if server_name:
            ret = dialog.select("Select Server - %s" %  title,server_name)
            rq = requests.post(link,data='id=%s&serv=%s' % (anime_id, server_id[ret]),headers=Headers).text

            file = t.Request('',rq).find("iframe")['src']

            if 'anyanime.com' in file:
                html = t.Request(file,'')

                if "iframe" in str(html):
                    file = html.find("iframe")['src']
                elif "embed" in str(html):
                    file = html.find("embed")['src']

        if file:
            #host = urlresolver._get_host(file)
            #.SourceCode(host)
            file = urlresolver.resolve(file)
            infoLabels = { "Title": title,"Plot":desc,"year": year,"genre": genre,
                            "episode": 04,"sortepisode": 04,"rating": 6.4,"playcount": 5222,"mpaa": "PG-13"
                        }

            listitem = xbmcgui.ListItem(path = file,iconImage=cover, thumbnailImage=cover) 
            listitem.setInfo( type="video", infoLabels = infoLabels )            
            xbmcplugin.setResolvedUrl(PluginHandle, True, listitem) 
            xbmcplugin.endOfDirectory(PluginHandle)
    #except:
        #dialog.notification(c.Addon_name, 'Info: Kein Servers', xbmcgui.NOTIFICATION_INFO, 5000)

#--------------------------------------------Codigo Importante------------------------------------------



def addDir(name,url,mode,iconimage,genres,plot,year,cm=False):    
    fanart = iconimage.replace('-220x300','')
    labels = {'title': name,'sorttitle': name,'genre': genres,'year': year,'director':'ithrinet',
        'duration': '','plot': plot,'episode': '','rating': 9.9 
        }

    u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels=labels )
    if cm:
        item.addContextMenuItems( cm )

    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)

def addLink(name,url,mode,iconimage,genres,plot,year,cm=False):
    fanart = iconimage.replace('-220x300','')
    labels = {'title': name,'sorttitle': name,'genre': genres,'year': year,'director':'ithrinet',
        'duration': '','plot': plot,'episode': '','rating': 9.9

        }

    u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels=labels )
    item.setProperty('IsPlayable', 'true')
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)



args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    Menu()
else:
    exec '%s()' % mode[0]