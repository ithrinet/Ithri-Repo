# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on
# Version 0.1

import sys,os
import urllib,re,urlparse, json
import xbmc,xbmcgui,xbmcplugin
import requests,urlresolver
from resources.lib import tools
from resources.lib import common as c
from bs4 import BeautifulSoup as bs

reload(sys)
sys.setdefaultencoding('utf-8')

dialog = xbmcgui.Dialog()
pdialog = xbmcgui.DialogProgress()

PluginHandle = int(sys.argv[1])

Headers = c.headers('Chrome')

BaseUrl = 'https://egyanime.com'
session = requests.Session()
c.addon_data()
c.addon_temp()

tmdb_base = 'https://api.themoviedb.org/3'
tmdb_key = '2ab10ff6afda491d22e70604dbdc6442'
tmdb_query = 'query=%s'
tmdb_lang = 'language=%s' % "ar" # Ejemplo es-Es, ar-SA, ar-EA, de
tmdb_img = 'https://image.tmdb.org/t/p/original'


def Menu():
    addDir('Ultimos Episodios','t22','Ultimos','','','')
    addDir('Episodios Destacados','t11','Ultimos','','','')
    #addDir('Ultimos Animes Añadidos','','Destacados','','','')
    #addDir('Ultimos Movies Añadidos','','Destacados','','','')
    #addDir('Animes Mas Visotos','owl-most-viewed-animes','Ultimos','','','')
    addDir('Animes','list','SubMenu','','','')
    addDir('Peliculas','movies','SubMenu','','','')
    #addDir('Search','','Search','','','')
    #addDir('My Liste','','Perfil','','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def SubMenu():
    url = "%s/%s" % (BaseUrl,args['url'][0])

    addDir('All',url,'Items','','','')
    addDir('A-Z',url,'Category','','','')    
    addDir('Genres',url,'Category','','','')
    addDir('Rated',url + '?do=rate','Items','','','')

    if 'list' in args['url'][0]:
        addDir('Anime Collections','%s/%s' % (BaseUrl,'series'),'Items','','','')

    #addDir('State',url,'Category','','',url)
    xbmcplugin.endOfDirectory(PluginHandle)

def Ultimos():
    url = args['url'][0]
    
    html = Request(BaseUrl,'')
    items = html.find(id=url).find_all(class_="one-episode")

    for item in items:
        title = item.h1.string
        eps = re.sub(r'[^\d\w\s-]+','',item.find(class_="episode-number").text).strip()
        url = '%s/%s' % (BaseUrl,item.a['href'])
        
        tmdb_url = '%s/search/tv?api_key=%s&query=%s&%s' % (tmdb_base,tmdb_key,title,tmdb_lang)
        tmdb_json = requests.get(tmdb_url,headers=Headers).json()
        tmdb_result = tmdb_json['results']
        #tmdb_id = tmdb_json['results'][0][id]

        if tmdb_result:
            result = tmdb_result[0]
            tmdb_url_id = '%s/tv/%s?api_key=%s&%s'% (tmdb_base,result['id'],tmdb_key,tmdb_lang)
            tmdb_resul = requests.get(tmdb_url_id,headers=Headers).json()
            #_id = result['id']
            #name_org = result['original_name']
            img = '%s/%s' % (tmdb_img,tmdb_resul['poster_path'])
            fanart = '%s/%s' % (tmdb_img,tmdb_resul['backdrop_path'])
            plot = tmdb_resul['overview']

        else:
            #name = title
            img = img = '%s/%s' % (BaseUrl,item.img['src'])
            fanart = img = '%s/%s' % (BaseUrl,item.img['src'])
            plot = ''

        #img = '%s/%s' % (BaseUrl,item.img['src'])
        #added_date = item.h2.string#

        name = '%s - [COLOR red]%03d[/COLOR]' % (title,int(eps)) if eps.isdigit() else '%s - [COLOR red]%s[/COLOR]' % (title,eps)
        addLink(name,url,'Stream',img,fanart,plot)
    
    xbmcplugin.setContent(PluginHandle, 'movies')
    xbmcplugin.endOfDirectory(PluginHandle)

def Category():
    name = args['name'][0]
    #_type = args['_type'][0]
    host = '%s?do=' % args['url'][0]

    html = Request(host,'')#.find_all(class_="dropdown-menu scrollable-menu")

    if name == 'A-Z':
        url = '%sa_z#sort=%s'
        addDir('#',url % (host,'another'),'Items','','','')
        for item in c.Alphabet:
            addDir(item,url % (host,item.lower()),'Items','','','')

    elif name == 'State':
        addDir('in Emission',BaseUrl+'','Items','','','')
        addDir('Finalized',BaseUrl+'','Items','','','')

    elif name == 'Genres':
        url = '%stype#sort=%s'
        for item in c.Genres:
            addDir(item,url % (host,item.lower()),'Items','','','')

    elif name == 'Legand':
        items = html[5].find_all("li")
        for item in items:
            addDir(item.a.string,item.a['href'],'Items','','','')

    xbmcplugin.endOfDirectory(PluginHandle)

def Data_info():
    url = 'http://egyanime.com/ajx/info_a.php'
    url = 'http://egyanime.com/anime?do=1'
    url = 'http://egyanime.com/ajx/ajax.php'
    info_a = 'info_a=1'

    Header = {
        'Host' : 'egyanime.com',
        'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36',
        'Accept' : '*/*',
        'Accept-Encoding' : 'gzip, deflate',
        'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With' : 'XMLHttpRequest',
        'Referer' : 'http://egyanime.com/list?do=legand',
        #'POSTDATA' : 'load=1&limit=8'
    }
    #rq = session.post(url,headers=Header)
    rq = session.post(url,data ='load=1&limit=8',headers=Header)
    tools.SourceCode(rq.text)
     

def Items():
    try:        
        url = args['url'][0].replace('#','&')
        #_type = args['_type'][0]

        html = Request(url,'')
        items = html.find_all('div',class_="episode-wrap")
        pagins = html.find('nav',class_="pagination")


        #Ejemplo de HTML Para Sacar Informacion de los Animes, tite, url, image, ETC
        '''
        <div class="episode-wrap">
            <a href="anime?do=511">
                <figure class="image">
                    <img alt="egyanime-IMG" src="uploads/9221537720901187.7406702041626.jpg"></img>
                </figure>
                <p class="episode-number"><i class="fa fa-star rate"> 1</i></p>
                <h1>RErideD: Tokigoe no Derrida</h1>
                <div class="hover-episode-meta">
                    <p><i class="fa fa-lg fa-play"></i> فتح</p>
                </div>
            </a>
        </div> 
        '''
        for item in items:
            title = item.h1.string
            href = '%s/%s' % (BaseUrl,item.a['href'])
            img = '%s/%s' % (BaseUrl,item.img["src"])

            if 'movie' in href:
                url = href.replace('do=','w=')
                addLink(title,url,'Stream',img,'','')

            elif 'serie' in href:
                addDir(title,href,'Items',img,'','')

            elif 'anime' in href:
                addDir(title,href,'Episodes',img,'','')

        if pagins:
            next_page = "%s/list%s" % (BaseUrl,pagins.find(class_="pagination-next")['href'])
            addDir('Next Page',next_page,'Items','','','')
            #tools.SourceCode(next_page)

        xbmcplugin.setContent(PluginHandle, 'movies')
        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Animes gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Episodes():
    try:
        url = '%s&perPage=1000' % args['url'][0]
        title = args['name'][0]
        logo = args['iconimage'][0]
        
        html = Request(url,'')
        items = html.find("tbody").find_all("tr")

        #Formulario para sacar los episodios del Anime seleccionado
        '''
        <tr>
          <td>حــلــقة  1 </td>
          <td><a href="watch?w=12808"><i class="fa fa-play"></i> تشغيل</a></td>
        </tr>
        '''
        #items.reverse()
        if items:
            for item in items:
                ep = re.sub(r'[^\d\w\s-]+','',item.td.string).strip()
                #tools.SourceCode(ep)
                #tools.SourceCode(ep.isdigit())

                url = "%s/%s" % (BaseUrl,item.a['href'])
                name = '%s - [COLOR red]%03d[/COLOR]' % (title,int(ep)) if ep.isdigit() else '%s - [COLOR red]%s[/COLOR]' % (title,ep)
                addLink(name,url,'Stream',logo,'','')
            xbmcplugin.endOfDirectory(PluginHandle)
        else:
            dialog.notification(c.Addon_name, 'Info: Kein Episodes gefunden', xbmcgui.NOTIFICATION_INFO, 5000)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Episodes gefunden', xbmcgui.NOTIFICATION_INFO, 5000)

def Stream():
    try:
        url = args['url'][0]
        name = args['name'][0]
        logo = args['iconimage'][0]

        server_name = []
        server_url = []
        html = Request(url,'')

        items_play = html.find(id="tabs" ).find_all("a")
        items_down = html.find(class_="message is-dark")
        

        index = 0
        if items_down:            
            items = items_down.find_all("a")
            for item in items:
                index += 1
                title = re.sub(r'[^\w\s]+','',item.text).strip()
                href = item['href']
                name_d = '%02d | [B]%s[/B]' % (index,title.replace('HD','').title())
                server_name.append(name_d)
                server_url.append(href)

        for item in items_play:
            index += 1  
            url =  "%s/movie%s" % (BaseUrl,item['href']) if '/movie' in url else "%s/watch%s" % (BaseUrl,item['href'])
            title = re.sub(r'[^\w\s]+','',item.text).strip()
            name_p = '%02d | [B]%s[/B]' % (index,title.replace('HD','').title())
            server_name.append(name_p)
            server_url.append(url)

        ret = dialog.select('Select Server : %s' % title,server_name)
        link = Request(server_url[ret],'').find("iframe")["src"] if 'egyanime.com' in server_url[ret] else server_url[ret]
        link = link.replace('drive.','docs.').replace('uc?id=','file/d/').replace('&export=download','/preview')      

        if len(server_url) > 1:
            if ret != -1 and urlresolver.HostedMediaFile(link).valid_url():
                file = urlresolver.resolve(link)
                Play(name,file,logo)
            else:
                tst = 'Sss'
        else:
            file = urlresolver.resolve(link)
            Play(name,file,logo)

        xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Streams Links gefunden', xbmcgui.NOTIFICATION_INFO, 5000)


#--------------------------------------------------Codigo Antigou---------------------------------------------------

def Search():
    try:
        url = '%s/?s=%s&search_param=%s'
        kb = xbmc.Keyboard ('', 'Suche %s' % c.Addon_name, False)    
        kb.doModal()
        if (kb.isConfirmed() and kb.getText() !=''):
            items = Request(url % (BaseUrl,kb.getText(),'animes'),'').find_all(class_="am-card")
        
            for item in items:
                #addDir(item.img['alt'],item.a['href'],'Episodes',item.img['src'],'','')
                addDir(item.h3.a.string,item.h3.a['href'],'Episodes',item.img['src'].replace('-215x300',''),'','')
            xbmcplugin.setContent(PluginHandle, 'movies')
            xbmcplugin.endOfDirectory(PluginHandle)
    except:
        dialog.notification(c.Addon_name, 'Info: Kein Resultat gefunden', xbmcgui.NOTIFICATION_INFO, 5000)


#----------------------------------------------Basico---------------------


def Play(name,url,logo):
    if url:
        listitem = xbmcgui.ListItem(path = url,iconImage=logo, thumbnailImage=logo) 
        listitem.setInfo( type="video", infoLabels={ "title": name } )            
        xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    else:
        xbmcgui.Dialog().ok(c.Addon_name,'Notification(Info: Kein Stream gefunden,)')

def addDir(name,url,mode,iconimage,fanart,plot,cm=False):

    u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot} )
    if cm:
        item.addContextMenuItems( cm )

    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)

def addLink(name,url,mode,iconimage,fanart,plot,cm=False):

    u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+name+"&iconimage="+iconimage
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)    
    item.setArt({ 'fanart': fanart,'poster': iconimage,'banner' : iconimage })
    item.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot} )
    item.setProperty('IsPlayable', 'true')
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)

def Request(host,data):
    if data == "html5":
        rq = session.get(host,headers=Headers)
        sp = bs(rq.content,'html5lib')
    else:
        rq = session.get(host,headers=Headers)
        sp = bs(rq.content,"html.parser")
    return sp


args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    Menu()
else:
    exec '%s()' % mode[0]