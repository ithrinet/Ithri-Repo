# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Rifalbum.com
# Version 0.1

import os,re,xbmc
import requests
import json
from resources.lib import common
headers = common.headers('Chrome')

def get_thumbs (img):
    return os.path.join(common.Addon_thumbs,img)

def trans(string):
    return common.Translations(string).encode("utf-8")

def SourceCode(content):
    File = open(common.HTMLData,'a')
    File.write(str('%s \n' % content))
    File.close()

def get_domain(url):
    m = re.match('((https?):\/\/)?(\w+\.)*(?P<domain>\w+)\.(\w+)(\/.*)?', url)
    if m:
        domain = m.group('domain')
        return domain
    else:
        return False