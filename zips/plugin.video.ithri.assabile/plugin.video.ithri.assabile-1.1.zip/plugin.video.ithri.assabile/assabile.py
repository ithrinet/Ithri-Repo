# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for AnimeFLV.Net
# Version 0.1

#-----------------------Codigo Util-------------------------------------
import sys
import urllib,re,os,urlparse
import xbmc,xbmcaddon,xbmcvfs
import xbmcgui,xbmcplugin
import requests,json
from resources.lib import tools
from resources.lib import common as c


_host = c.Host
headers = c.headers('Chrome')

PluginHandle = int(sys.argv[1])

c.addon_data()
c.addon_temp()

def kategorien():
    addDir(c.trans(30001),'','Quran','','')
    addDir(c.trans(30002),'','Anasheed','','')    
    addDir(c.trans(30003),'','Durus','','')
    addDir(c.trans(30004),'','Search','','')
    addDir(c.trans(30005),'','my_favs','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Search():
    pass

def Quran(): 
    addDir(c.trans(30006),_host+'/quran','Reciters','','')
    addDir(c.trans(30007),_host+'/quran/suwar','Sowar','','')
    addDir(c.trans(30008),'Al-Massahef','Al_Massahef','','')
    addDir(c.trans(30009),_host+'/quran/riwayat','Riwayat','','')
    addDir(c.trans(300010),_host+'/quran/top','Tracks','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Anasheed():
    addDir(c.trans(300011),_host+'/anasheed','Reciters','','')
    addDir(c.trans(300012),_host+'/anasheed/top','Tracks','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Durus():
    addDir(c.trans(300013),_host+'/lesson','Reciters','','')
    addDir(c.trans(300014),_host+'/lesson/lastseries','Last_durus','','')
    addDir(c.trans(300015),_host+'/lesson/topseries','Last_durus','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def my_favs():    
    try:
        entries = tools.get_my_favs()
        for entry in entries:
            title = entry['title']            
            url = entry['url']
            cover = entry['cover']
            cm = []
            u3=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&name="+urllib.quote_plus(title)+"&mode="+urllib.quote_plus('remove_my_favs')
            cm.append( ('Delete From My Favs', "XBMC.RunPlugin(%s)" % u3) )
            addDir(title,url,'Reciters_menu',cover,'',cm=cm)
        xbmcplugin.endOfDirectory(PluginHandle)
    except: xbmc.executebuiltin('Notification(Keine Favs)')

def Last_durus():
    host = args['url'][0]
    name = args['name'][0]
    r = requests.get(host, headers=headers)
    paterns = 'team-image.*?href="(.*?)".*?src="(.*?)".*? title="(.*?)".*?<span>(.*?)</span>'
    lesson = re.findall(paterns,r.content, re.DOTALL)
    for url, img, title, reciter in lesson:
        name = reciter+' - '+title
        url = _host+url
        img = _host+img
        addDir(name,url,'Videos',img,'')

    paterns = 'active.*?person">.*?<a href="(.*?)">(.*?)</a>.*?</li>'
    pagin = re.findall(paterns,r.content)
    for url, num in pagin:
        url =_host+url
        name = 'Next Page: '+num
        addDir(name,url,'Last_durus','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Al_Massahef():
    url = args['url'][0]
    if url == 'Al-Massahef':
        almasahef = c.Al_Massahef
        for title, url in almasahef:
            addDir(title,_host+url,'Al_Massahef','','')
    else:
        content = requests.get(url,headers=headers).content
        paterns = 'h2_sourat">.*?<a href="(.*?)".*?data-name="(.*?)".*?recite.*?recited by (.*?)</span>'
        almasahef = re.findall(paterns,content, re.DOTALL)
        for url,title, reciter in almasahef:
            img = _host+'/media/person/200x256/'+reciter.lower().replace(' ','-')+'.png'
            url = _host+url
            title = title+ ' - recited by ('+reciter+')'
            addDir(title,url,'Tracks',img,'')

        paterns = 'active.*?person">.*?<a href="(.*?)">(.*?)</a>.*?</li>'
        pagin = re.findall(paterns,content)
        for url, num in pagin:
            url =_host+url
            name = 'Next Page: '+num
            addDir(name,url,'Al_Massahef','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Riwayat():
    url = args['url'][0]
    content = requests.get(url,headers=headers).content
    paterns = 'h2_sourat".*?href="(.*?)".*?title="(.*?)".*?>'
    riwayat = re.findall(paterns, content, re.DOTALL)
    for url,title in riwayat:
        addDir(title,_host+url,'Al_Massahef','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Sowar():
    host = args['url'][0]
    content = requests.get(host, headers=headers).content
    paterns = 'h2_sourat.*?href="(.*?)".*?data-default="(.*?)"'
    suwar = re.findall(paterns, content, re.DOTALL)
    for url,ide in suwar:
        url = _host+url
        name = tools.get_sura(ide)
        addDir(name,url,'Tracks','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def Reciters():
    host = args['url'][0]
    name = args['name'][0]
    r = requests.get(host, headers=headers)

    if name == c.trans(30006) or name == c.trans(300011) or name == c.trans(300013):         
        paterns = '<a href="(.*?)" class="filtre">(.*?)</a>'
        country = re.findall(paterns,r.content)
        addDir('All',host,'Reciters','','')
        for url,name in country:
            url = _host+url
            addDir(name,url,'Reciters','','')
    else:
        paterns = 'isotope-item.*?<a href="(.*?)".*?<img src="(.*?)" alt="(.*?)".*?</a>'
        reciters = re.findall(paterns,r.content, re.DOTALL)
        for url,img,name in reciters:
            url = _host+url
            img = _host+img
            cm=[]
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&cover="+urllib.quote_plus(img)+"&name="+urllib.quote_plus(name)+"&mode="+urllib.quote_plus('add_to_my_favs')
            cm.append( ('Add To Watch Later', "XBMC.RunPlugin(%s)" % u))
            addDir(name,url,'Reciters_menu',img,'',cm=cm)

        paterns = 'active.*?person">.*?<a href="(.*?)">(.*?)</a>.*?</li>'
        pagin = re.findall(paterns,r.content)
        for url, num in pagin:
            url =_host+url
            name = 'Next Page: '+num
            addDir(name,url,'Reciters','','')
        xbmc.executebuiltin('Container.SetViewMode(500)')
    xbmcplugin.endOfDirectory(PluginHandle)

def Reciters_menu():
    link = args['url'][0]
    r = requests.get(link, headers=headers)
    paterns = '<ul.*?nav-tabs">(.*?)</ul>'
    data = re.findall(paterns,r.content,re.DOTALL)[0]
    matches = re.findall('<a href="(.*?)">(.*?)</a>',data, re.DOTALL)
    for url,name in matches:
        host = _host+url
        if '/videos' in url:
            addDir(name,host,'Videos','','')
        elif '/collection' in url or '/quran' in url:
            r = requests.get(host, headers=headers)
            data = re.findall('<ul.*?id="riwaya">(.*?)</ul>',r.content, re.DOTALL)[0]
            collection = re.findall('<a rel="nofollow" href="(.*?)">(.*?)</a>',data, re.DOTALL)
            #collection.pop(0)
            for url, name in collection:
                url = _host+url
                addDir(name,url,'Tracks','','')
        elif '/album' in  url:
            addDir('Anasheed Albums',host,'Albums','','')
            r = requests.get(link, headers=headers)           
            person_id = re.findall("id_person = '(.*?)';",r.content,re.DOTALL)[0]
            host = _host+'/ajax/album-player-'+person_id
            content = requests.get(host, headers=headers).content
            paterns = '<a rel="nofollow" class="link-media never".+?href="(.*?)".*?title="(.*?)".*?timer">(.*?)</div>'
            tracks = re.findall(paterns,content,re.DOTALL)
            for url,title,time in tracks:
                url = _host+'/ajax/getsnng-link-'+url.replace('#','')
                time = c.get_time(time)
                addLink(title,url,'PlayItems','','',time)
        elif '/series' in url:
            r = requests.get(host, headers=headers)
            paterns = 'pf-uielements.*?href="(.*?)".*?src="(.*?)".*?</a>.*?title-ptf-lstpp.*?href.*?>(.*?)</a>'
            albums = re.findall(paterns,r.content,re.DOTALL)
            for url, img, title in albums:
                url = _host+url
                img = _host+img
                addDir(title,url,'Videos',img,'')
    xbmcplugin.endOfDirectory(PluginHandle)

def Albums():
    host = args['url'][0]
    name = args['name'][0]
    r = requests.get(host, headers=headers)
    paterns = 'pf-uielements.*?href="(.*?)".*?src="(.*?)".*?</a>.*?title-ptf-lstpp.*?href.*?>(.*?)</a>'
    albums = re.findall(paterns,r.content,re.DOTALL)
    for url, img, title in albums:
        url = _host+url
        img = _host+img
        addDir(title,url,'Tracks',img,'')
    xbmcplugin.endOfDirectory(PluginHandle)

def Tracks():
    host = args['url'][0]
    name = args['name'][0]
    r = requests.get(host, headers=headers)
    try:
        json_data = json.loads(r.content)
        json_data = json_data['Recitation']
        for item in json_data:
            ide = item['data-default']
            time = c.get_time(item['duration'])
            name = item['name'] + item['span_name']
            url = 'http://www.assabile.com/ajax/getrcita-link-'+item['href'].replace('#','')
            addLink(name.encode('utf-8'),url,'PlayItems','','',time)
    except:
        if '/suwar/'in host:
            paterns= '<a rel="nofollow" class="link-media never" href="(.*?)".*?data-riwaya="(.*?)" title="(.*?)".*?timer">(.*?)</div>'
            suwar = re.findall(paterns,r.content,re.DOTALL)
            for url,riwaya, reciter,time in suwar:
                url = 'http://www.assabile.com/ajax/getrcita-link-'+url.replace('#','')
                name = name+' - recited by ('+reciter+' - '+riwaya+')'
                time = c.get_time(time)
                addLink(name,url,'PlayItems','','',time)
        elif '/album/' in host:
            paterns = ' <div class="name" itemprop.*?href="(.*?)".*?data-title="(.*?)".*?>'
            tracks= re.findall(paterns,r.content,re.DOTALL)
            for url, title in tracks:
                url = _host+'/ajax/getsnng-link-'+url.replace('#','')
                addLink(title,url,'PlayItems','','','')
        elif name == 'Top 40':
            paterns = '<a.*?nofollow".*?ink-med.*?ever.*?href="(.*?)".*?title="(.*?)".*?</a>'
            tracks = re.findall(paterns,r.content,re.DOTALL)
            for url,title in tracks:
                url = _host+'/ajax/getsnng-link-'+url.replace('#','')
                addLink(title,url,'PlayItems','','','')
        else:
            paterns = '<a.*?nofollow".*?ink-med.*?ever.*?href="(.*?)".*?data-ver.*?data-default="(.*?)".*?timer">(.*?)</div>'
            suwar = re.findall(paterns,r.content,re.DOTALL)
            for url,ide,time in suwar:
                url = 'http://www.assabile.com/ajax/getrcita-link-'+url.replace('#','')
                name = tools.get_sura(ide)
                time = c.get_time(time)
                addLink(name,url,'PlayItems','','',time)                
    xbmcplugin.endOfDirectory(PluginHandle)

def Videos():
    host = args['url'][0]
    name = args['name'][0]
    r = requests.get(host,headers=headers)
    if '/series' in host:
        paterns = 'pisode"><met.*?prop="name".*?content.*?day">(.*?)<.*?<a href="(.*?)">(.*?)</a>.*?<img src="(.*?)".*?/>'
        videos = re.findall(paterns,r.content, re.DOTALL)
        for time,link, title, img in videos:
            link = _host+link
            img = _host+img
            time = c.get_time(time+':00')
            content = requests.get(link,headers=headers).content
            file = re.findall('file: "(.*?)",',content, re.DOTALL)[0]
            addLink(title,file,'Play',img,'',time)
    elif '/videos' in host:
        paterns = 'videoall-wh.*?href="(.*?)".*?img src="(.*?)".*?title-ptf.*?href.*?>(.*?)</a>'
        videos = re.findall(paterns,r.content, re.DOTALL)
        for link, img, title in videos:
            link = _host+link
            img = _host+img
            content = requests.get(link,headers=headers).content
            file = re.findall('file: "(.*?)",',content, re.DOTALL)[0]
            addLink(title,file,'Play',img,'','')

    paterns = 'active.*?person">.*?<a href="(.*?)">(.*?)</a>.*?</li>'
    pagin = re.findall(paterns,r.content)
    for url, num in pagin:
        url =_host+url
        name = 'Next Page: '+num
        addDir(name,url,'Videos','','')
    xbmcplugin.endOfDirectory(PluginHandle)

def PlayItems():
    host = args['url'][0]
    name = args['name'][0]
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36','X-Requested-With':'XMLHttpRequest'}
    content = requests.get(host, headers=headers).content
    file = re.findall('(http.*.mp3)', content)[0]
    if file:
        #xbmcgui.Dialog().ok(AddonName,'El Url Es '+ url)
        listitem = xbmcgui.ListItem(path = file)
        listitem.setInfo( type="audio", infoLabels={ "title": name } )
        xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    else:
        xbmcgui.Dialog().ok(AddonName,'Notification(Info: Kein Stream gefunden,)')

def Play():
    url = args['url'][0]
    name = args['name'][0]

    if url:
        listitem = xbmcgui.ListItem(path = url)
        listitem.setInfo( type="video", infoLabels={ "title": name } )            
        xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    else:
        xbmcgui.Dialog().ok(AddonName,'Notification(Info: Kein Stream gefunden,)')

def Play_Streams(file,name):
    
    if file:
        listitem = xbmcgui.ListItem(path = file)
        listitem.setInfo( type="video", infoLabels={ "title": name } )            
        xbmcplugin.setResolvedUrl(PluginHandle, True, listitem)
    else:
        xbmcgui.Dialog().ok(c.Addon_name,'Notification(Info: Kein Stream gefunden,)')

def addLink(name,url,mode,iconimage,plot,duration,cm=False):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+str(name)
    item=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
    item.setProperty('IsPlayable', 'true')
    item.addStreamInfo('video', { 'duration' : duration })
    if cm:
        item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item)

def addDir(name,url,mode,iconimage,plot,cm=False):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
    item=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setArt({ 'fanart': iconimage, 'banner' : iconimage })
    item.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
    if cm:        
        item.addContextMenuItems( cm )

    xbmcplugin.addDirectoryItem(PluginHandle,url=u,listitem=item,isFolder=True)

def add_to_my_favs():
    #try:
    title = args['name'][0]
    url = args['url'][0]
    cover = args['cover'][0]
    tools.set_my_favs(title,url,cover)
    #except: pass

def remove_my_favs():
    try:
        url = args['url'][0]
        tools.remove_my_favs(url)
    except: pass

def remove_history():
    key = args['name'][0]
    url = args['url'][0]
    try: 
        tools.remove_history(key,url)
    except: pass

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    kategorien()
else:
    exec '%s()' % mode[0]